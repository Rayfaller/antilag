#!/bin/bash
# Local DNS VPN - Installer for Termux/Android

set -e

RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
CYAN='\033[0;36m'
NC='\033[0m'

echo -e "${CYAN}"
echo "=================================================="
echo "  LOCAL DNS VPN - Instalador Termux"
echo "=================================================="
echo -e "${NC}"

# Detect Termux
if [ -n "$TERMUX_VERSION" ] || [ -d "/data/data/com.termux" ]; then
    echo -e "${GREEN}✓ Termux detectado${NC}"
    IS_TERMUX=1
else
    echo -e "${YELLOW}⚠ Termux não detectado${NC}"
    IS_TERMUX=0
fi

# Check Python
if ! command -v python3 &> /dev/null; then
    echo -e "${RED}✗ Python3 não encontrado${NC}"
    if [ "$IS_TERMUX" = "1" ]; then
        echo "Instalando Python..."
        pkg update -y
        pkg install python -y
    else
        echo "Instale Python3 manualmente"
        exit 1
    fi
fi

PYTHON_VER=$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
echo -e "${GREEN}✓ Python $PYTHON_VER${NC}"

# Install directory
INSTALL_DIR="${HOME}/.local_dns_vpn"
mkdir -p "$INSTALL_DIR"
cd "$INSTALL_DIR"

SCRIPT_DIR="$(cd "$(dirname "$0")/.." && pwd)"

echo -e "${CYAN}Instalando em: $INSTALL_DIR${NC}"

# Copy files
echo "Copiando arquivos..."
if [ -d "$SCRIPT_DIR/termux" ]; then
    cp -r "$SCRIPT_DIR/termux" "$INSTALL_DIR/"
    cp -r "$SCRIPT_DIR/config" "$INSTALL_DIR/"
    cp -r "$SCRIPT_DIR/tests" "$INSTALL_DIR/"
    cp "$SCRIPT_DIR/requirements.txt" "$INSTALL_DIR/"
else
    echo -e "${RED}Erro: Diretório termux/ não encontrado em $SCRIPT_DIR${NC}"
    exit 1
fi

mkdir -p "$INSTALL_DIR/logs"

# Install Python dependencies
echo "Instalando dependências Python..."
pip install --user -r requirements.txt 2>/dev/null || pip install -r requirements.txt

# Create executable
cat > "$INSTALL_DIR/dns" << 'EXEC_EOF'
#!/data/data/com.termux/files/usr/bin/bash
# Local DNS VPN wrapper

export PYTHONPATH="${HOME}/.local_dns_vpn:${PYTHONPATH}"
cd "${HOME}/.local_dns_vpn"
python3 -m termux.resolver.cli "$@"
EXEC_EOF

chmod +x "$INSTALL_DIR/dns"

# Symlink to PATH
BIN_DIR="${HOME}/.local/bin"
mkdir -p "$BIN_DIR"
ln -sf "$INSTALL_DIR/dns" "$BIN_DIR/dns"

# Add to PATH
if [[ ":$PATH:" != *":$BIN_DIR:"* ]]; then
    echo 'export PATH="$HOME/.local/bin:$PATH"' >> ~/.bashrc
    echo -e "${YELLOW}Adicionado $BIN_DIR ao PATH. Execute 'source ~/.bashrc'${NC}"
fi

# Termux boot script
if [ "$IS_TERMUX" = "1" ]; then
    mkdir -p ~/.termux/boot
    cat > ~/.termux/boot/start-local-dns << 'BOOT_EOF'
#!/data/data/com.termux/files/usr/bin/sh
termux-wake-lock
cd "$HOME/.local_dns_vpn"
python3 -m termux.resolver.cli start
BOOT_EOF
    chmod +x ~/.termux/boot/start-local-dns 2>/dev/null || true
    echo -e "${GREEN}✓ Script de boot criado${NC}"
fi

# Create uninstall script
cat > "$INSTALL_DIR/uninstall.sh" << 'UNINST_EOF'
#!/bin/bash
echo "Desinstalando Local DNS VPN..."
python3 -m termux.resolver.cli stop 2>/dev/null || true
rm -f "$HOME/.local/bin/dns"
rm -rf "$HOME/.local_dns_vpn"
rm -f ~/.termux/boot/start-local-dns
echo "Desinstalado."
UNINST_EOF
chmod +x "$INSTALL_DIR/uninstall.sh"

echo ""
echo -e "${GREEN}==================================================${NC}"
echo -e "${GREEN}  Instalação concluída!${NC}"
echo -e "${GREEN}==================================================${NC}"
echo ""
echo "Comandos:"
echo "  dns start        - Iniciar resolver"
echo "  dns stop         - Parar resolver"
echo "  dns restart      - Reiniciar resolver"
echo "  dns status       - Ver status"
echo "  dns benchmark    - Benchmark upstreams"
echo "  dns diagnose     - Diagnóstico"
echo "  dns stats        - Estatísticas"
echo "  dns cache        - Cache stats"
echo "  dns clear-cache  - Limpar cache"
echo "  dns upstreams    - Status upstreams"
echo "  dns config       - Ver configuração"
echo "  dns logs         - Ver logs"
echo ""
echo "Para desinstalar: bash ~/.local_dns_vpn/uninstall.sh"
echo ""
echo "IMPORTANTE:"
echo "1. Instale o app Android (veja docs/ANDROID_BUILD.md)"
echo "2. Inicie o resolver: dns start"
echo "3. Ative a VPN no app Android"
echo "4. Pronto! Seu DNS está protegido e otimizado"
echo ""
