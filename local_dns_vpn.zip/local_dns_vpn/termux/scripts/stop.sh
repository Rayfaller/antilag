#!/bin/bash
cd "$(dirname "$0")/.."
export PYTHONPATH="$(pwd):${PYTHONPATH}"
python3 -m termux.resolver.cli stop "$@"
