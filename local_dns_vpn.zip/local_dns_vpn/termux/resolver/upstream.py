# -*- coding: utf-8 -*-
"""
Local DNS VPN - Upstream Manager
Manages upstream DNS servers with circuit breaker, health checks,
and intelligent selection based on real performance data.
"""

import time
import threading
import socket
import struct
import random
from typing import Dict, List, Optional, Any
from dataclasses import dataclass, field
from enum import Enum

from termux.resolver.utils import get_logger, Timer, ExponentialMovingAverage
from termux.resolver.config import get_config

logger = get_logger()

class CircuitState(Enum):
    CLOSED = "closed"
    OPEN = "open"
    HALF_OPEN = "half_open"

@dataclass
class UpstreamServer:
    name: str
    addresses: List[str]
    port: int = 53
    weight: float = 1.0

    latency_ema: ExponentialMovingAverage = field(default_factory=lambda: ExponentialMovingAverage(0.3))
    latency_history: List[float] = field(default_factory=list)
    success_count: int = 0
    failure_count: int = 0
    timeout_count: int = 0
    total_queries: int = 0
    last_used: float = 0.0

    circuit_state: CircuitState = CircuitState.CLOSED
    circuit_failures: int = 0
    circuit_last_failure: float = 0.0
    circuit_half_open_calls: int = 0

    current_score: float = 0.0
    last_benchmarked: float = 0.0

    def record_success(self, latency_ms: float) -> None:
        self.latency_ema.update(latency_ms)
        self.latency_history.append(latency_ms)
        if len(self.latency_history) > 100:
            self.latency_history = self.latency_history[-50:]
        self.success_count += 1
        self.total_queries += 1
        self.last_used = time.time()

        if self.circuit_state == CircuitState.HALF_OPEN:
            self.circuit_half_open_calls += 1
            cfg = get_config()
            if self.circuit_half_open_calls >= cfg.get("upstream.circuit_breaker.half_open_max_calls", 3):
                self._close_circuit()

    def record_failure(self, is_timeout: bool = False) -> None:
        self.failure_count += 1
        self.total_queries += 1
        if is_timeout:
            self.timeout_count += 1

        cfg = get_config()
        threshold = cfg.get("upstream.circuit_breaker.failure_threshold", 5)

        if self.circuit_state == CircuitState.CLOSED:
            self.circuit_failures += 1
            if self.circuit_failures >= threshold:
                self._open_circuit()
        elif self.circuit_state == CircuitState.HALF_OPEN:
            self._open_circuit()

    def _open_circuit(self) -> None:
        self.circuit_state = CircuitState.OPEN
        self.circuit_last_failure = time.time()
        self.circuit_half_open_calls = 0
        logger.warning(f"Circuit OPEN for {self.name}")

    def _close_circuit(self) -> None:
        self.circuit_state = CircuitState.CLOSED
        self.circuit_failures = 0
        self.circuit_half_open_calls = 0
        logger.info(f"Circuit CLOSED for {self.name}")

    def check_recovery(self) -> bool:
        if self.circuit_state != CircuitState.OPEN:
            return True
        recovery = get_config().get("upstream.circuit_breaker.recovery_timeout", 60)
        if time.time() - self.circuit_last_failure > recovery:
            self.circuit_state = CircuitState.HALF_OPEN
            self.circuit_half_open_calls = 0
            logger.info(f"Circuit HALF_OPEN for {self.name}")
            return True
        return False

    @property
    def is_available(self) -> bool:
        if self.circuit_state == CircuitState.OPEN:
            return self.check_recovery()
        return True

    @property
    def success_rate(self) -> float:
        return self.success_count / self.total_queries if self.total_queries > 0 else 1.0

    @property
    def average_latency(self) -> float:
        if self.latency_ema.value is not None:
            return self.latency_ema.value
        if self.latency_history:
            return sum(self.latency_history) / len(self.latency_history)
        return float('inf')

    @property
    def latency_std(self) -> float:
        if len(self.latency_history) < 2:
            return 0.0
        mean = sum(self.latency_history) / len(self.latency_history)
        variance = sum((x - mean) ** 2 for x in self.latency_history) / len(self.latency_history)
        return variance ** 0.5

    @property
    def stability(self) -> float:
        avg = self.average_latency
        if avg == 0 or not self.latency_history:
            return 1.0
        return max(0, 1.0 - (self.latency_std / avg))

    def get_stats(self) -> Dict[str, Any]:
        return {
            "name": self.name,
            "addresses": self.addresses,
            "port": self.port,
            "circuit_state": self.circuit_state.value,
            "latency_avg_ms": round(self.average_latency, 2),
            "latency_std_ms": round(self.latency_std, 2),
            "success_rate": round(self.success_rate * 100, 2),
            "total_queries": self.total_queries,
            "successes": self.success_count,
            "failures": self.failure_count,
            "timeouts": self.timeout_count,
            "stability": round(self.stability, 3),
            "score": round(self.current_score, 2),
            "weight": self.weight,
        }

class UpstreamManager:
    def __init__(self):
        self.config = get_config()
        self.servers: Dict[str, UpstreamServer] = {}
        self._lock = threading.RLock()
        self._current_primary: Optional[str] = None
        self._health_thread: Optional[threading.Thread] = None
        self._running = False
        self._initialize_servers()
        logger.info(f"UpstreamManager: {len(self.servers)} servers initialized")

    def _initialize_servers(self) -> None:
        for cfg in self.config.get_upstream_servers():
            server = UpstreamServer(
                name=cfg["name"],
                addresses=cfg["addresses"],
                port=cfg.get("port", 53),
                weight=cfg.get("weight", 1.0)
            )
            self.servers[cfg["name"]] = server

    def get_server(self, name: Optional[str] = None) -> Optional[UpstreamServer]:
        with self._lock:
            if name:
                return self.servers.get(name)
            if self._current_primary and self._current_primary in self.servers:
                s = self.servers[self._current_primary]
                if s.is_available:
                    return s
            return self._select_best()

    def get_all_servers(self) -> List[UpstreamServer]:
        with self._lock:
            return list(self.servers.values())

    def get_available_servers(self) -> List[UpstreamServer]:
        with self._lock:
            return [s for s in self.servers.values() if s.is_available]

    def _select_best(self) -> Optional[UpstreamServer]:
        available = [s for s in self.servers.values() if s.is_available]
        if not available:
            logger.error("No upstream servers available!")
            return None
        available.sort(key=lambda s: s.current_score, reverse=True)
        best = available[0]
        self._current_primary = best.name
        return best

    def update_scores(self, scores: Dict[str, float]) -> None:
        with self._lock:
            for name, score in scores.items():
                if name in self.servers:
                    self.servers[name].current_score = score
                    self.servers[name].last_benchmarked = time.time()
        self._select_best()

    def record_result(self, server_name: str, success: bool, latency_ms: float, is_timeout: bool = False) -> None:
        with self._lock:
            if server_name in self.servers:
                if success:
                    self.servers[server_name].record_success(latency_ms)
                else:
                    self.servers[server_name].record_failure(is_timeout)

    def get_fallback_chain(self) -> List[UpstreamServer]:
        with self._lock:
            available = [s for s in self.servers.values() if s.is_available]
            available.sort(key=lambda s: s.current_score, reverse=True)
            return available

    def start_health_checks(self) -> None:
        if self._running:
            return
        self._running = True
        self._health_thread = threading.Thread(target=self._health_loop, daemon=True)
        self._health_thread.start()
        logger.info("Health checks started")

    def stop_health_checks(self) -> None:
        self._running = False
        if self._health_thread and self._health_thread.is_alive():
            self._health_thread.join(timeout=2)
        logger.info("Health checks stopped")

    def _health_loop(self) -> None:
        interval = self.config.get("upstream.health_check_interval", 60)
        while self._running:
            time.sleep(interval)
            if not self._running:
                break
            try:
                for server in self.servers.values():
                    if not server.is_available:
                        continue
                    try:
                        latency = self._quick_ping(server)
                        server.record_success(latency)
                    except Exception:
                        server.record_failure(is_timeout=True)
            except Exception as e:
                logger.error(f"Health check error: {e}")

    def _quick_ping(self, server: UpstreamServer) -> float:
        query = self._build_query(".", 2)
        with Timer() as timer:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.settimeout(2.0)
            try:
                sock.sendto(query, (server.addresses[0], server.port))
                sock.recvfrom(512)
            finally:
                sock.close()
        return timer.milliseconds

    def _build_query(self, domain: str, record_type: int) -> bytes:
        tid = random.randint(0, 65535)
        flags = 0x0100
        header = struct.pack('!HHHHHH', tid, flags, 1, 0, 0, 0)
        qname = b''
        for part in domain.rstrip('.').split('.'):
            qname += bytes([len(part)]) + part.encode()
        qname += b'\x00'
        return header + qname + struct.pack('!HH', record_type, 1)

    def get_stats(self) -> Dict[str, Any]:
        with self._lock:
            return {
                "primary": self._current_primary,
                "total": len(self.servers),
                "available": len(self.get_available_servers()),
                "servers": {name: s.get_stats() for name, s in self.servers.items()}
            }
