# -*- coding: utf-8 -*-
"""
Local DNS VPN - Configuration Manager
Centralized configuration with validation and defaults.
"""

import json
import os
from typing import Dict, List, Any, Optional

DEFAULT_CONFIG = {
    "general": {
        "listen_address": "127.0.0.1",
        "listen_port": 5353,
        "log_level": "INFO",
        "log_file": "logs/local_dns.log",
        "max_log_size_mb": 5,
        "log_backup_count": 2,
        "pid_file": "logs/local_dns.pid",
        "daemon": False,
        "workers": 2,
        "log_dns_queries": False,
    },
    "cache": {
        "enabled": True,
        "max_size": 5000,
        "ttl_override": None,
        "min_ttl": 60,
        "max_ttl": 86400,
        "negative_ttl": 300,
        "prefetch": True,
        "prefetch_threshold": 0.8,
    },
    "upstream": {
        "servers": [
            {"name": "Cloudflare", "addresses": ["1.1.1.1", "1.0.0.1"], "port": 53, "weight": 1.0},
            {"name": "Google", "addresses": ["8.8.8.8", "8.8.4.4"], "port": 53, "weight": 1.0},
            {"name": "Quad9", "addresses": ["9.9.9.9", "149.112.112.112"], "port": 53, "weight": 1.0},
        ],
        "timeout": 2.0,
        "retries": 2,
        "fallback_enabled": True,
        "circuit_breaker": {
            "enabled": True,
            "failure_threshold": 5,
            "recovery_timeout": 60,
            "half_open_max_calls": 3,
        },
        "selection_mode": "balanced",
        "benchmark_interval": 600,
        "health_check_interval": 60,
    },
    "benchmark": {
        "enabled": True,
        "test_domains": [
            "google.com", "cloudflare.com", "github.com", "reddit.com",
            "stackoverflow.com", "amazon.com", "youtube.com", "wikipedia.org",
            "twitter.com", "linkedin.com"
        ],
        "queries_per_server": 8,
        "warmup_queries": 2,
        "score_weights": {
            "latency_avg": 0.4,
            "latency_p95": 0.2,
            "success_rate": 0.3,
            "stability": 0.1,
        },
        "latency_penalty": 10.0,
        "timeout_penalty": 100.0,
        "failure_penalty": 50.0,
        "instability_penalty": 25.0,
    },
    "coalescing": {
        "enabled": True,
        "window_ms": 50,
        "max_waiters": 100,
    },
    "modes": {
        "fast": {
            "latency_weight": 0.7,
            "stability_weight": 0.2,
            "reliability_weight": 0.1,
            "switch_threshold": 1.2,
            "min_samples": 5,
        },
        "balanced": {
            "latency_weight": 0.4,
            "stability_weight": 0.4,
            "reliability_weight": 0.2,
            "switch_threshold": 1.3,
            "min_samples": 10,
        },
        "stable": {
            "latency_weight": 0.2,
            "stability_weight": 0.5,
            "reliability_weight": 0.3,
            "switch_threshold": 1.5,
            "min_samples": 15,
        },
    },
    "android": {
        "vpn_virtual_dns": "10.0.0.2",
        "vpn_interface": "10.0.0.1",
        "vpn_prefix": 24,
        "termux_socket_path": "/data/data/com.termux/files/usr/tmp/local_dns.sock",
        "termux_port": 5354,
    },
}


class Config:
    def __init__(self, config_path: Optional[str] = None):
        self.config_path = config_path or self._find_config_file()
        self.data = self._load_config()
        self._validate()

    def _find_config_file(self) -> str:
        possible_paths = [
            os.environ.get("LOCAL_DNS_CONFIG"),
            "config/config.json",
            os.path.expanduser("~/.config/local_dns/config.json"),
            os.path.expanduser("~/.local_dns/config.json"),
        ]
        for path in possible_paths:
            if path and os.path.isfile(path):
                return path
        return "config/config.json"

    def _load_config(self) -> Dict[str, Any]:
        if os.path.isfile(self.config_path):
            try:
                with open(self.config_path, 'r', encoding='utf-8') as f:
                    user_config = json.load(f)
                return self._merge_configs(DEFAULT_CONFIG, user_config)
            except (json.JSONDecodeError, IOError) as e:
                print(f"Warning: Could not load config: {e}. Using defaults.")
        return DEFAULT_CONFIG.copy()

    def _merge_configs(self, default: Dict, user: Dict) -> Dict:
        result = default.copy()
        for key, value in user.items():
            if key in result and isinstance(result[key], dict) and isinstance(value, dict):
                result[key] = self._merge_configs(result[key], value)
            else:
                result[key] = value
        return result

    def _validate(self) -> None:
        port = self.data["general"]["listen_port"]
        if not (1024 <= port <= 65535):
            raise ValueError(f"Port must be >= 1024 (no root required). Got: {port}")
        if self.data["cache"]["max_size"] < 100:
            raise ValueError("Cache max_size must be at least 100")
        if not self.data["upstream"]["servers"]:
            raise ValueError("At least one upstream server required")
        mode = self.data["upstream"]["selection_mode"]
        if mode not in self.data["modes"]:
            raise ValueError(f"Invalid mode: {mode}")

    def get(self, key: str, default: Any = None) -> Any:
        keys = key.split('.')
        value = self.data
        for k in keys:
            if isinstance(value, dict) and k in value:
                value = value[k]
            else:
                return default
        return value

    def set(self, key: str, value: Any) -> None:
        keys = key.split('.')
        target = self.data
        for k in keys[:-1]:
            if k not in target:
                target[k] = {}
            target = target[k]
        target[keys[-1]] = value

    def save(self, path: Optional[str] = None) -> None:
        save_path = path or self.config_path
        os.makedirs(os.path.dirname(save_path) or '.', exist_ok=True)
        with open(save_path, 'w', encoding='utf-8') as f:
            json.dump(self.data, f, indent=2, ensure_ascii=False)

    def get_mode_config(self) -> Dict[str, Any]:
        mode = self.data["upstream"]["selection_mode"]
        return self.data["modes"].get(mode, self.data["modes"]["balanced"])

    def get_upstream_servers(self) -> List[Dict[str, Any]]:
        return self.data["upstream"]["servers"]


_config_instance: Optional[Config] = None

def get_config(config_path: Optional[str] = None) -> Config:
    global _config_instance
    if _config_instance is None or config_path is not None:
        _config_instance = Config(config_path)
    return _config_instance

def reload_config(config_path: Optional[str] = None) -> Config:
    global _config_instance
    _config_instance = Config(config_path)
    return _config_instance
