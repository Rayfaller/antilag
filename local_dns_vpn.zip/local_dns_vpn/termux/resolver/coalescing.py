# -*- coding: utf-8 -*-
"""
Local DNS VPN - Request Coalescing
Deduplicates simultaneous identical DNS queries to reduce upstream load.
If 100 apps ask for google.com at the same time, only 1 upstream query is made.
"""

import time
import threading
from typing import Dict, List, Optional, Callable
from dataclasses import dataclass, field

from termux.resolver.utils import get_logger

logger = get_logger()

@dataclass
class PendingQuery:
    domain: str
    record_type: int
    query_data: bytes
    waiters: List[Callable] = field(default_factory=list)
    created_at: float = field(default_factory=time.time)
    resolved: bool = False
    response: Optional[bytes] = None

    @property
    def age_ms(self) -> float:
        return (time.time() - self.created_at) * 1000

class QueryCoalescer:
    def __init__(self, window_ms: float = 50.0, max_waiters: int = 100):
        self.window_ms = window_ms
        self.max_waiters = max_waiters
        self._pending: Dict[str, PendingQuery] = {}
        self._lock = threading.Lock()
        self._coalesced_count = 0
        self._total_waiters = 0

        logger.info(f"QueryCoalescer: window={window_ms}ms, max_waiters={max_waiters}")

    def _make_key(self, domain: str, record_type: int) -> str:
        return f"{domain.lower()}:{record_type}"

    def coalesce_or_execute(self, domain: str, record_type: int, query_data: bytes,
                           execute_fn: Callable, callback: Callable) -> bool:
        """
        Try to coalesce query. Returns True if coalesced (callback will be called later),
        False if this thread should execute the query.
        """
        key = self._make_key(domain, record_type)

        with self._lock:
            # Clean old entries
            self._cleanup_old()

            if key in self._pending and not self._pending[key].resolved:
                pending = self._pending[key]
                if len(pending.waiters) < self.max_waiters:
                    pending.waiters.append(callback)
                    self._total_waiters += 1
                    self._coalesced_count += 1
                    logger.debug(f"Coalesced query for {domain} (waiters: {len(pending.waiters)})")
                    return True
                else:
                    logger.warning(f"Max waiters reached for {domain}, executing new query")

            # Create new pending query
            self._pending[key] = PendingQuery(
                domain=domain,
                record_type=record_type,
                query_data=query_data
            )
            self._pending[key].waiters.append(callback)
            return False

    def resolve_pending(self, domain: str, record_type: int, response: Optional[bytes]) -> None:
        """Resolve a pending query and notify all waiters."""
        key = self._make_key(domain, record_type)

        with self._lock:
            if key not in self._pending:
                return

            pending = self._pending[key]
            pending.resolved = True
            pending.response = response
            waiters = pending.waiters[:]
            self._total_waiters -= len(waiters)
            del self._pending[key]

        # Notify waiters outside lock to avoid deadlocks
        for callback in waiters:
            try:
                callback(response)
            except Exception as e:
                logger.error(f"Error notifying waiter: {e}")

        if len(waiters) > 1:
            logger.debug(f"Resolved {domain} for {len(waiters)} waiters (coalesced)")

    def _cleanup_old(self) -> None:
        """Remove old resolved or expired pending queries."""
        now = time.time()
        to_remove = []
        for key, pending in self._pending.items():
            if pending.resolved or (now - pending.created_at) * 1000 > self.window_ms * 10:
                to_remove.append(key)
        for key in to_remove:
            if key in self._pending:
                self._total_waiters -= len(self._pending[key].waiters)
                del self._pending[key]

    def get_stats(self) -> Dict:
        with self._lock:
            return {
                "coalesced_queries": self._coalesced_count,
                "active_pending": len(self._pending),
                "total_waiters": self._total_waiters,
                "window_ms": self.window_ms,
            }
