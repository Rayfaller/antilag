# -*- coding: utf-8 -*-
"""
Local DNS VPN - Statistics
Tracks query statistics, uptime, and performance metrics.
"""

import time
import threading
from typing import Dict, Any
from dataclasses import dataclass, field

from termux.resolver.utils import AtomicCounter

@dataclass
class ResolverStats:
    start_time: float = field(default_factory=time.time)
    total_queries: AtomicCounter = field(default_factory=lambda: AtomicCounter(0))
    total_failures: AtomicCounter = field(default_factory=lambda: AtomicCounter(0))
    cache_hits: AtomicCounter = field(default_factory=lambda: AtomicCounter(0))
    cache_misses: AtomicCounter = field(default_factory=lambda: AtomicCounter(0))
    upstream_queries: AtomicCounter = field(default_factory=lambda: AtomicCounter(0))
    fallback_count: AtomicCounter = field(default_factory=lambda: AtomicCounter(0))
    coalesced_count: AtomicCounter = field(default_factory=lambda: AtomicCounter(0))
    avg_latency_ms: float = 0.0
    _latency_sum: float = 0.0
    _latency_count: int = 0
    _lock: threading.Lock = field(default_factory=threading.Lock)

    def record_query(self, success: bool, from_cache: bool = False, 
                    latency_ms: float = 0.0, is_fallback: bool = False,
                    is_coalesced: bool = False) -> None:
        self.total_queries.increment()
        if not success:
            self.total_failures.increment()
        if from_cache:
            self.cache_hits.increment()
        else:
            self.cache_misses.increment()
            self.upstream_queries.increment()
        if is_fallback:
            self.fallback_count.increment()
        if is_coalesced:
            self.coalesced_count.increment()

        if latency_ms > 0:
            with self._lock:
                self._latency_sum += latency_ms
                self._latency_count += 1
                self.avg_latency_ms = self._latency_sum / self._latency_count

    @property
    def uptime_seconds(self) -> float:
        return time.time() - self.start_time

    @property
    def failure_rate(self) -> float:
        total = self.total_queries.value
        return (self.total_failures.value / total * 100) if total > 0 else 0.0

    @property
    def cache_hit_rate(self) -> float:
        total = self.cache_hits.value + self.cache_misses.value
        return (self.cache_hits.value / total * 100) if total > 0 else 0.0

    def to_dict(self) -> Dict[str, Any]:
        return {
            "uptime_seconds": round(self.uptime_seconds, 2),
            "uptime_formatted": self._format_uptime(),
            "total_queries": self.total_queries.value,
            "total_failures": self.total_failures.value,
            "failure_rate": round(self.failure_rate, 2),
            "cache_hits": self.cache_hits.value,
            "cache_misses": self.cache_misses.value,
            "cache_hit_rate": round(self.cache_hit_rate, 2),
            "upstream_queries": self.upstream_queries.value,
            "fallback_count": self.fallback_count.value,
            "coalesced_count": self.coalesced_count.value,
            "avg_latency_ms": round(self.avg_latency_ms, 2),
        }

    def _format_uptime(self) -> str:
        s = int(self.uptime_seconds)
        h = s // 3600
        m = (s % 3600) // 60
        s = s % 60
        return f"{h:02d}:{m:02d}:{s:02d}"
