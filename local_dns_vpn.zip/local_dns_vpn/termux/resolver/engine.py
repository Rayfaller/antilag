# -*- coding: utf-8 -*-
"""
Local DNS VPN - DNS Engine
Core resolution engine: cache -> coalescing -> upstream -> fallback.
Supports A, AAAA, CNAME, MX, TXT, NXDOMAIN, SERVFAIL.
"""

import time
import struct
import socket
import threading
from typing import Optional, Tuple, Dict, List

from termux.resolver.utils import get_logger, Timer
from termux.resolver.config import get_config
from termux.resolver.cache import DNSCache
from termux.resolver.upstream import UpstreamManager, UpstreamServer
from termux.resolver.benchmark import BenchmarkSystem
from termux.resolver.coalescing import QueryCoalescer
from termux.resolver.stats import ResolverStats

logger = get_logger()

# DNS Record Types
A = 1
NS = 2
CNAME = 5
SOA = 6
PTR = 12
MX = 15
TXT = 16
AAAA = 28
SRV = 33
ANY = 255

RECORD_NAMES = {
    1: 'A', 2: 'NS', 5: 'CNAME', 6: 'SOA', 12: 'PTR',
    15: 'MX', 16: 'TXT', 28: 'AAAA', 33: 'SRV', 255: 'ANY'
}

class DNSEngine:
    def __init__(self):
        self.config = get_config()
        self.cache = DNSCache(
            max_size=self.config.get("cache.max_size", 5000),
            min_ttl=self.config.get("cache.min_ttl", 60),
            max_ttl=self.config.get("cache.max_ttl", 86400),
            negative_ttl=self.config.get("cache.negative_ttl", 300),
            ttl_override=self.config.get("cache.ttl_override")
        )
        self.upstream_manager = UpstreamManager()
        self.benchmark = BenchmarkSystem(self.upstream_manager)
        self.coalescer = QueryCoalescer(
            window_ms=self.config.get("coalescing.window_ms", 50),
            max_waiters=self.config.get("coalescing.max_waiters", 100)
        )
        self.stats = ResolverStats()

        self._concurrent = 0
        self._concurrent_lock = threading.Lock()

        if self.config.get("cache.enabled", True):
            self.cache.start_cleanup()
        self.upstream_manager.start_health_checks()
        if self.config.get("benchmark.enabled", True):
            self.benchmark.start_auto()

        logger.info("DNSEngine initialized")

    def resolve(self, query_data: bytes, source_addr: Tuple[str, int]) -> Optional[bytes]:
        """Main resolution pipeline."""
        with self._concurrent_lock:
            self._concurrent += 1

        try:
            return self._do_resolve(query_data)
        finally:
            with self._concurrent_lock:
                self._concurrent -= 1

    def _do_resolve(self, query_data: bytes) -> Optional[bytes]:
        domain, record_type = self._parse_query(query_data)
        if not domain:
            return self._build_error(query_data, rcode=1)  # FORMERR

        log_queries = self.config.get("general.log_dns_queries", False)
        if log_queries:
            logger.debug(f"Query: {domain} {RECORD_NAMES.get(record_type, record_type)}")

        # Check cache
        if self.config.get("cache.enabled", True):
            cached = self.cache.get(domain, record_type)
            if cached:
                self.stats.record_query(success=True, from_cache=True)
                return self._update_tid(cached, query_data[:2])

        # Try coalescing
        if self.config.get("coalescing.enabled", True):
            result_container = {"response": None, "done": threading.Event()}

            def callback(response):
                result_container["response"] = response
                result_container["done"].set()

            if self.coalescer.coalesce_or_execute(domain, record_type, query_data, 
                                                   self._execute_query, callback):
                # Wait for coalesced result
                result_container["done"].wait(timeout=10.0)
                if result_container["response"]:
                    self.stats.record_query(success=True, from_cache=False, is_coalesced=True)
                    return self._update_tid(result_container["response"], query_data[:2])
                else:
                    # Coalescer timeout, execute directly
                    pass

        # Execute query
        response = self._execute_query(domain, record_type, query_data)

        if response:
            ttl = self._extract_ttl(response)
            is_negative = self._is_negative(response)
            self.cache.put(domain, record_type, response, ttl, is_negative)
            self.stats.record_query(success=True, from_cache=False, latency_ms=0)
            self.coalescer.resolve_pending(domain, record_type, response)
        else:
            self.stats.record_query(success=False)
            self.coalescer.resolve_pending(domain, record_type, None)

        return response

    def _execute_query(self, domain: str, record_type: int, query_data: bytes) -> Optional[bytes]:
        """Execute query with fallback chain."""
        timeout = self.config.get("upstream.timeout", 2.0)
        retries = self.config.get("upstream.retries", 2)
        servers = self.upstream_manager.get_fallback_chain()

        if not servers:
            logger.error("No upstream servers available")
            return self._build_error(query_data, rcode=2)

        for attempt, server in enumerate(servers):
            for retry in range(retries):
                try:
                    with Timer() as timer:
                        response = self._query_server(server, query_data, timeout)

                    if response:
                        self.upstream_manager.record_result(
                            server.name, True, timer.milliseconds
                        )
                        if attempt > 0:
                            self.stats.record_query(success=True, is_fallback=True)
                            logger.info(f"Fallback to {server.name} succeeded")
                        return response
                except socket.timeout:
                    self.upstream_manager.record_result(
                        server.name, False, 0, is_timeout=True
                    )
                except Exception as e:
                    self.upstream_manager.record_result(server.name, False, 0)
                    logger.debug(f"Query to {server.name} failed: {e}")

        logger.error(f"All upstreams failed for {domain}")
        return self._build_error(query_data, rcode=2)

    def _query_server(self, server: UpstreamServer, query_data: bytes, timeout: float) -> Optional[bytes]:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.settimeout(timeout)
        try:
            sock.sendto(query_data, (server.addresses[0], server.port))
            response, _ = sock.recvfrom(4096)
            if len(response) >= 12:
                tid = struct.unpack('!H', query_data[:2])[0]
                resp_tid = struct.unpack('!H', response[:2])[0]
                if resp_tid == tid:
                    return response
        finally:
            sock.close()
        return None

    def _parse_query(self, data: bytes) -> Tuple[Optional[str], int]:
        if len(data) < 12:
            return None, 0
        offset = 12
        parts = []
        while offset < len(data):
            length = data[offset]
            if length == 0:
                offset += 1
                break
            if length & 0xC0 == 0xC0:
                offset += 2
                break
            offset += 1
            parts.append(data[offset:offset + length].decode('utf-8', errors='ignore'))
            offset += length
        domain = '.'.join(parts)
        if offset + 4 <= len(data):
            record_type = struct.unpack('!H', data[offset:offset + 2])[0]
            return domain, record_type
        return domain, 1

    def _extract_ttl(self, response: bytes) -> int:
        try:
            _, _, questions, answers, _, _ = struct.unpack('!HHHHHH', response[:12])
            offset = 12
            for _ in range(questions):
                while offset < len(response):
                    l = response[offset]
                    offset += 1
                    if l == 0:
                        offset += 4
                        break
                    if l & 0xC0 == 0xC0:
                        offset += 1
                        offset += 4
                        break
                    offset += l
            if answers > 0 and offset + 10 <= len(response):
                while offset < len(response):
                    l = response[offset]
                    offset += 1
                    if l == 0 or l & 0xC0 == 0xC0:
                        break
                    offset += l
                if l & 0xC0 == 0xC0:
                    offset += 1
                offset += 4  # TYPE + CLASS
                if offset + 4 <= len(response):
                    return struct.unpack('!I', response[offset:offset + 4])[0]
            return 300
        except Exception:
            return 300

    def _is_negative(self, response: bytes) -> bool:
        try:
            flags = struct.unpack('!H', response[2:4])[0]
            return (flags & 0x000F) == 3  # NXDOMAIN
        except Exception:
            return False

    def _build_error(self, query: bytes, rcode: int = 2) -> bytes:
        if len(query) < 12:
            return b''
        tid = struct.unpack('!H', query[:2])[0]
        flags = 0x8000 | (rcode & 0x000F)
        qdcount = struct.unpack('!H', query[4:6])[0]
        header = struct.pack('!HHHHHH', tid, flags, qdcount, 0, 0, 0)
        return header + query[12:]

    def _update_tid(self, response: bytes, new_tid: bytes) -> bytes:
        return new_tid + response[2:]

    def get_stats(self) -> Dict:
        return {
            **self.stats.to_dict(),
            "concurrent_queries": self._concurrent,
            "cache": self.cache.get_stats(),
            "upstream": self.upstream_manager.get_stats(),
            "benchmark": self.benchmark.get_stats(),
            "coalescing": self.coalescer.get_stats(),
        }

    def shutdown(self) -> None:
        logger.info("Shutting down DNSEngine...")
        self.cache.stop_cleanup()
        self.upstream_manager.stop_health_checks()
        self.benchmark.stop_auto()
        logger.info("DNSEngine shutdown complete")
