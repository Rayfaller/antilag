# -*- coding: utf-8 -*-
"""
Local DNS VPN - Cache
Efficient DNS cache with TTL respect, LRU eviction, and stats.
"""

import time
import threading
from typing import Dict, Optional, List, Any
from collections import OrderedDict
from dataclasses import dataclass, field

from termux.resolver.utils import get_logger, AtomicCounter

logger = get_logger()

@dataclass
class CacheEntry:
    domain: str
    record_type: int
    response_data: bytes
    ttl: int
    created_at: float = field(default_factory=time.time)
    access_count: int = 0
    last_accessed: float = field(default_factory=time.time)

    @property
    def is_expired(self) -> bool:
        return time.time() > self.created_at + self.ttl

    @property
    def remaining_ttl(self) -> int:
        remaining = int(self.ttl - (time.time() - self.created_at))
        return max(0, remaining)

    @property
    def age(self) -> float:
        return time.time() - self.created_at

    def touch(self) -> None:
        self.access_count += 1
        self.last_accessed = time.time()

class DNSCache:
    def __init__(self, max_size: int = 5000, min_ttl: int = 60,
                 max_ttl: int = 86400, negative_ttl: int = 300,
                 ttl_override: Optional[int] = None):
        self.max_size = max_size
        self.min_ttl = min_ttl
        self.max_ttl = max_ttl
        self.negative_ttl = negative_ttl
        self.ttl_override = ttl_override

        self._cache: OrderedDict[str, CacheEntry] = OrderedDict()
        self._lock = threading.RLock()

        self._hits = AtomicCounter(0)
        self._misses = AtomicCounter(0)
        self._evictions = AtomicCounter(0)
        self._expirations = AtomicCounter(0)

        self._cleanup_interval = 60
        self._cleanup_thread: Optional[threading.Thread] = None
        self._running = False

        logger.info(f"Cache: max={max_size}, min_ttl={min_ttl}s, max_ttl={max_ttl}s")

    def _make_key(self, domain: str, record_type: int) -> str:
        return f"{domain.lower()}:{record_type}"

    def _clamp_ttl(self, ttl: int) -> int:
        if self.ttl_override is not None:
            return self.ttl_override
        return max(self.min_ttl, min(ttl, self.max_ttl))

    def get(self, domain: str, record_type: int = 1) -> Optional[bytes]:
        key = self._make_key(domain, record_type)
        with self._lock:
            entry = self._cache.get(key)
            if entry is None:
                self._misses.increment()
                return None
            if entry.is_expired:
                del self._cache[key]
                self._expirations.increment()
                self._misses.increment()
                return None
            entry.touch()
            self._cache.move_to_end(key)
            self._hits.increment()
            return entry.response_data

    def put(self, domain: str, record_type: int, response_data: bytes,
            ttl: int, is_negative: bool = False) -> None:
        key = self._make_key(domain, record_type)
        effective_ttl = self.negative_ttl if is_negative else self._clamp_ttl(ttl)

        entry = CacheEntry(
            domain=domain.lower(),
            record_type=record_type,
            response_data=response_data,
            ttl=effective_ttl
        )

        with self._lock:
            while len(self._cache) >= self.max_size:
                self._evict_oldest()
            self._cache[key] = entry
            self._cache.move_to_end(key)

    def _evict_oldest(self) -> None:
        if self._cache:
            oldest = next(iter(self._cache))
            del self._cache[oldest]
            self._evictions.increment()

    def clear(self) -> int:
        with self._lock:
            count = len(self._cache)
            self._cache.clear()
        self._hits.reset()
        self._misses.reset()
        self._evictions.reset()
        self._expirations.reset()
        logger.info(f"Cache cleared: {count} entries")
        return count

    def cleanup_expired(self) -> int:
        removed = 0
        with self._lock:
            expired = [k for k, e in self._cache.items() if e.is_expired]
            for k in expired:
                del self._cache[k]
                removed += 1
        if removed > 0:
            self._expirations.increment(removed)
        return removed

    def start_cleanup(self) -> None:
        if self._running:
            return
        self._running = True
        self._cleanup_thread = threading.Thread(target=self._cleanup_loop, daemon=True)
        self._cleanup_thread.start()
        logger.info("Cache cleanup started")

    def stop_cleanup(self) -> None:
        self._running = False
        if self._cleanup_thread and self._cleanup_thread.is_alive():
            self._cleanup_thread.join(timeout=2)
        logger.info("Cache cleanup stopped")

    def _cleanup_loop(self) -> None:
        while self._running:
            time.sleep(self._cleanup_interval)
            if not self._running:
                break
            try:
                self.cleanup_expired()
            except Exception as e:
                logger.error(f"Cleanup error: {e}")

    @property
    def size(self) -> int:
        with self._lock:
            return len(self._cache)

    @property
    def hit_rate(self) -> float:
        total = self._hits.value + self._misses.value
        return (self._hits.value / total * 100) if total > 0 else 0.0

    @property
    def miss_rate(self) -> float:
        total = self._hits.value + self._misses.value
        return (self._misses.value / total * 100) if total > 0 else 0.0

    def get_stats(self) -> Dict[str, Any]:
        with self._lock:
            expired = sum(1 for e in self._cache.values() if e.is_expired)
            total_age = sum(e.age for e in self._cache.values())
            avg_age = total_age / len(self._cache) if self._cache else 0
        return {
            "entries": self.size,
            "expired": expired,
            "max_size": self.max_size,
            "hits": self._hits.value,
            "misses": self._misses.value,
            "hit_rate": round(self.hit_rate, 2),
            "miss_rate": round(self.miss_rate, 2),
            "evictions": self._evictions.value,
            "expirations": self._expirations.value,
            "avg_age": round(avg_age, 2),
            "memory_estimate_kb": round(self.size * 0.25, 2),
        }
