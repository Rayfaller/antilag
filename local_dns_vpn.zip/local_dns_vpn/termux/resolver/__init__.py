# Local DNS VPN - Termux Resolver Package
__version__ = "1.0.0"
