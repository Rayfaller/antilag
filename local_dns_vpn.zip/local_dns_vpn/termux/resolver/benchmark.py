# -*- coding: utf-8 -*-
"""
Local DNS VPN - Benchmark System
Automated performance testing with real measurements.
"""

import time
import threading
import statistics
from typing import Dict, List, Optional

from termux.resolver.utils import get_logger, Timer
from termux.resolver.config import get_config
from termux.resolver.upstream import UpstreamManager, UpstreamServer

logger = get_logger()

class BenchmarkResult:
    def __init__(self, server_name: str):
        self.server_name = server_name
        self.latencies: List[float] = []
        self.failures: int = 0
        self.timeouts: int = 0
        self.total_queries: int = 0
        self.start_time: float = 0.0
        self.end_time: float = 0.0

    def add_result(self, latency_ms: Optional[float], is_timeout: bool = False, is_failure: bool = False) -> None:
        self.total_queries += 1
        if latency_ms is not None:
            self.latencies.append(latency_ms)
        elif is_timeout:
            self.timeouts += 1
            self.failures += 1
        elif is_failure:
            self.failures += 1

    @property
    def success_count(self) -> int:
        return len(self.latencies)

    @property
    def success_rate(self) -> float:
        return self.success_count / self.total_queries if self.total_queries > 0 else 0.0

    @property
    def average_latency(self) -> float:
        return statistics.mean(self.latencies) if self.latencies else float('inf')

    @property
    def median_latency(self) -> float:
        return statistics.median(self.latencies) if self.latencies else float('inf')

    @property
    def min_latency(self) -> float:
        return min(self.latencies) if self.latencies else float('inf')

    @property
    def max_latency(self) -> float:
        return max(self.latencies) if self.latencies else float('inf')

    @property
    def p95_latency(self) -> float:
        if not self.latencies:
            return float('inf')
        s = sorted(self.latencies)
        return s[int(len(s) * 0.95)]

    @property
    def std_deviation(self) -> float:
        return statistics.stdev(self.latencies) if len(self.latencies) >= 2 else 0.0

    @property
    def stability(self) -> float:
        avg = self.average_latency
        if avg == 0 or not self.latencies:
            return 0.0
        return max(0, 1.0 - (self.std_deviation / avg))

    def calculate_score(self, weights: Dict[str, float], penalties: Dict[str, float]) -> float:
        if self.total_queries == 0:
            return 0.0
        latency_score = 1000.0 / (1 + self.average_latency)
        p95_score = 1000.0 / (1 + self.p95_latency)
        success_score = self.success_rate * 1000
        stability_score = self.stability * 1000

        score = (
            weights.get("latency_avg", 0.4) * latency_score +
            weights.get("latency_p95", 0.2) * p95_score +
            weights.get("success_rate", 0.3) * success_score +
            weights.get("stability", 0.1) * stability_score
        )
        score -= penalties.get("timeout", 100) * self.timeouts
        score -= penalties.get("failure", 50) * (self.failures - self.timeouts)
        score -= penalties.get("instability", 25) * (1 - self.stability)
        return max(0, score)

    def to_dict(self) -> Dict:
        return {
            "server": self.server_name,
            "total_queries": self.total_queries,
            "successes": self.success_count,
            "failures": self.failures,
            "timeouts": self.timeouts,
            "success_rate": round(self.success_rate * 100, 2),
            "latency_avg_ms": round(self.average_latency, 2),
            "latency_median_ms": round(self.median_latency, 2),
            "latency_min_ms": round(self.min_latency, 2),
            "latency_max_ms": round(self.max_latency, 2),
            "latency_p95_ms": round(self.p95_latency, 2),
            "latency_std_ms": round(self.std_deviation, 2),
            "stability": round(self.stability, 3),
            "duration_s": round(self.end_time - self.start_time, 2),
        }

class BenchmarkSystem:
    def __init__(self, upstream_manager: UpstreamManager):
        self.upstream_manager = upstream_manager
        self.config = get_config()
        self._last_time: float = 0.0
        self._last_results: Dict[str, BenchmarkResult] = {}
        self._lock = threading.Lock()
        self._thread: Optional[threading.Thread] = None
        self._running = False
        logger.info("BenchmarkSystem initialized")

    def run_benchmark(self, force: bool = False) -> Dict[str, BenchmarkResult]:
        with self._lock:
            interval = self.config.get("upstream.benchmark_interval", 600)
            if not force and time.time() - self._last_time < interval:
                return self._last_results
            self._last_time = time.time()

        logger.info("Starting benchmark...")
        test_domains = self.config.get("benchmark.test_domains", ["google.com"])
        queries_per = self.config.get("benchmark.queries_per_server", 8)
        warmup = self.config.get("benchmark.warmup_queries", 2)

        servers = self.upstream_manager.get_all_servers()
        results: Dict[str, BenchmarkResult] = {}

        for server in servers:
            result = self._benchmark_server(server, test_domains, queries_per, warmup)
            results[server.name] = result
            logger.info(f"Benchmarked {server.name}: avg={result.average_latency:.1f}ms, "
                       f"success={result.success_rate*100:.1f}%, score={result.calculate_score({}, {}):.1f}")

        scores = self._calculate_scores(results)
        self.upstream_manager.update_scores(scores)

        with self._lock:
            self._last_results = results

        logger.info("Benchmark completed")
        return results

    def _benchmark_server(self, server: UpstreamServer, domains: List[str],
                         queries_per: int, warmup: int) -> BenchmarkResult:
        result = BenchmarkResult(server.name)
        result.start_time = time.time()

        for _ in range(warmup):
            self._query(server, random.choice(domains))

        for domain in domains:
            for _ in range(queries_per // len(domains)):
                latency = self._query(server, domain)
                if latency is not None:
                    result.add_result(latency)
                else:
                    result.add_result(None, is_timeout=True)
                time.sleep(0.05)

        result.end_time = time.time()
        return result

    def _query(self, server: UpstreamServer, domain: str) -> Optional[float]:
        import struct
        tid = random.randint(0, 65535)
        flags = 0x0100
        header = struct.pack('!HHHHHH', tid, flags, 1, 0, 0, 0)
        qname = b''
        for part in domain.rstrip('.').split('.'):
            qname += bytes([len(part)]) + part.encode()
        qname += b'\x00'
        query = header + qname + struct.pack('!HH', 1, 1)

        timeout = self.config.get("upstream.timeout", 2.0)
        try:
            with Timer() as timer:
                sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                sock.settimeout(timeout)
                try:
                    sock.sendto(query, (server.addresses[0], server.port))
                    response, _ = sock.recvfrom(512)
                    if len(response) >= 12:
                        resp_tid = struct.unpack('!H', response[:2])[0]
                        if resp_tid == tid:
                            flags = struct.unpack('!H', response[2:4])[0]
                            if (flags & 0x000F) == 0:
                                return timer.milliseconds
                finally:
                    sock.close()
        except Exception:
            pass
        return None

    def _calculate_scores(self, results: Dict[str, BenchmarkResult]) -> Dict[str, float]:
        weights = self.config.get("benchmark.score_weights", {})
        penalties = {
            "timeout": self.config.get("benchmark.timeout_penalty", 100),
            "failure": self.config.get("benchmark.failure_penalty", 50),
            "instability": self.config.get("benchmark.instability_penalty", 25),
        }
        return {name: r.calculate_score(weights, penalties) for name, r in results.items()}

    def get_recommendation(self) -> Optional[str]:
        with self._lock:
            if not self._last_results:
                return None
            best = max(self._last_results.items(), key=lambda x: x[1].calculate_score({}, {}))
            return best[0]

    def get_comparison(self) -> List[Dict]:
        with self._lock:
            return [r.to_dict() for r in self._last_results.values()]

    def start_auto(self) -> None:
        if self._running:
            return
        self._running = True
        self._thread = threading.Thread(target=self._loop, daemon=True)
        self._thread.start()
        logger.info("Auto-benchmark started")

    def stop_auto(self) -> None:
        self._running = False
        if self._thread and self._thread.is_alive():
            self._thread.join(timeout=2)
        logger.info("Auto-benchmark stopped")

    def _loop(self) -> None:
        interval = self.config.get("upstream.benchmark_interval", 600)
        try:
            self.run_benchmark(force=True)
        except Exception as e:
            logger.error(f"Initial benchmark failed: {e}")
        while self._running:
            time.sleep(interval)
            if not self._running:
                break
            try:
                self.run_benchmark()
            except Exception as e:
                logger.error(f"Auto-benchmark error: {e}")

    def get_stats(self) -> Dict:
        with self._lock:
            return {
                "last_benchmark": self._last_time,
                "next_in": max(0, self.config.get("upstream.benchmark_interval", 600) - (time.time() - self._last_time)),
                "results": {name: r.to_dict() for name, r in self._last_results.items()}
            }
