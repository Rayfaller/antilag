# -*- coding: utf-8 -*-
"""
Local DNS VPN - Server
UDP DNS server + Unix socket server for Android VPN communication.
"""

import os
import socket
import threading
import signal
import struct
import json
from typing import Optional, Tuple

from termux.resolver.utils import get_logger, write_pid_file, remove_pid_file, read_pid_file, is_process_running
from termux.resolver.config import get_config
from termux.resolver.engine import DNSEngine

logger = get_logger()

class LocalDNSServer:
    def __init__(self, engine: DNSEngine):
        self.config = get_config()
        self.engine = engine
        self.udp_addr = self.config.get("general.listen_address", "127.0.0.1")
        self.udp_port = self.config.get("general.listen_port", 5353)
        self.unix_path = self.config.get("android.termux_socket_path", 
                                         "/data/data/com.termux/files/usr/tmp/local_dns.sock")

        self._udp_socket: Optional[socket.socket] = None
        self._unix_socket: Optional[socket.socket] = None
        self._running = False
        self._threads: List[threading.Thread] = []
        self._shutdown_event = threading.Event()

        self._setup_signals()
        logger.info(f"Server configured: UDP {self.udp_addr}:{self.udp_port}, Unix {self.unix_path}")

    def _setup_signals(self) -> None:
        def handler(signum, frame):
            logger.info(f"Signal {signum} received, shutting down...")
            self.stop()
        signal.signal(signal.SIGTERM, handler)
        signal.signal(signal.SIGINT, handler)

    def start(self) -> None:
        if self._running:
            return

        # Start UDP server
        try:
            self._udp_socket = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            self._udp_socket.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            self._udp_socket.bind((self.udp_addr, self.udp_port))
            self._udp_socket.settimeout(1.0)
            logger.info(f"UDP server bound to {self.udp_addr}:{self.udp_port}")
        except socket.error as e:
            logger.error(f"Failed to bind UDP: {e}")
            raise

        # Start Unix socket server for Android
        try:
            if os.path.exists(self.unix_path):
                os.remove(self.unix_path)
            self._unix_socket = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            self._unix_socket.bind(self.unix_path)
            self._unix_socket.listen(5)
            self._unix_socket.settimeout(1.0)
            os.chmod(self.unix_path, 0o777)  # Allow Android app to connect
            logger.info(f"Unix socket server bound to {self.unix_path}")
        except Exception as e:
            logger.error(f"Failed to bind Unix socket: {e}")
            # Continue without Unix socket - UDP still works
            self._unix_socket = None

        self._running = True
        self._shutdown_event.clear()

        pid_file = self.config.get("general.pid_file", "logs/local_dns.pid")
        write_pid_file(pid_file)

        # Start threads
        udp_thread = threading.Thread(target=self._udp_loop, daemon=True)
        udp_thread.start()
        self._threads.append(udp_thread)

        if self._unix_socket:
            unix_thread = threading.Thread(target=self._unix_loop, daemon=True)
            unix_thread.start()
            self._threads.append(unix_thread)

        logger.info("Server started")

    def _udp_loop(self) -> None:
        while self._running:
            try:
                data, addr = self._udp_socket.recvfrom(4096)
                if not self._running:
                    break
                threading.Thread(target=self._handle_udp, args=(data, addr), daemon=True).start()
            except socket.timeout:
                continue
            except OSError:
                break
            except Exception as e:
                logger.error(f"UDP loop error: {e}")

    def _handle_udp(self, data: bytes, addr: Tuple[str, int]) -> None:
        try:
            response = self.engine.resolve(data, addr)
            if response:
                self._udp_socket.sendto(response, addr)
        except Exception as e:
            logger.error(f"UDP handler error: {e}")

    def _unix_loop(self) -> None:
        while self._running:
            try:
                conn, _ = self._unix_socket.accept()
                if not self._running:
                    conn.close()
                    break
                threading.Thread(target=self._handle_unix, args=(conn,), daemon=True).start()
            except socket.timeout:
                continue
            except OSError:
                break
            except Exception as e:
                logger.error(f"Unix loop error: {e}")

    def _handle_unix(self, conn: socket.socket) -> None:
        """Handle Android app connection via Unix socket."""
        try:
            conn.settimeout(5.0)
            while self._running:
                # Read length-prefixed message
                length_data = conn.recv(4)
                if not length_data or len(length_data) < 4:
                    break
                msg_len = struct.unpack('!I', length_data)[0]
                if msg_len > 65535:
                    logger.warning(f"Message too large: {msg_len}")
                    break

                data = b''
                while len(data) < msg_len:
                    chunk = conn.recv(msg_len - len(data))
                    if not chunk:
                        break
                    data += chunk

                if len(data) < msg_len:
                    break

                # Parse message: first byte is type, rest is payload
                msg_type = data[0]
                payload = data[1:]

                if msg_type == 0x01:  # DNS Query
                    response = self.engine.resolve(payload, ("vpn", 0))
                    if response:
                        resp_data = struct.pack('!I', len(response)) + response
                        conn.sendall(resp_data)
                    else:
                        conn.sendall(struct.pack('!I', 0))

                elif msg_type == 0x02:  # Stats request
                    stats = self.engine.get_stats()
                    stats_json = json.dumps(stats, default=str).encode('utf-8')
                    conn.sendall(struct.pack('!I', len(stats_json)) + stats_json)

                elif msg_type == 0x03:  # Ping
                    conn.sendall(struct.pack('!I', 1) + b'\x01')
        except Exception as e:
            logger.debug(f"Unix handler error: {e}")
        finally:
            try:
                conn.close()
            except:
                pass

    def stop(self) -> None:
        if not self._running:
            return
        logger.info("Stopping server...")
        self._running = False
        self._shutdown_event.set()

        if self._udp_socket:
            try:
                self._udp_socket.close()
            except:
                pass
            self._udp_socket = None

        if self._unix_socket:
            try:
                self._unix_socket.close()
            except:
                pass
            if os.path.exists(self.unix_path):
                os.remove(self.unix_path)
            self._unix_socket = None

        for t in self._threads:
            if t.is_alive():
                t.join(timeout=2)

        pid_file = self.config.get("general.pid_file", "logs/local_dns.pid")
        remove_pid_file(pid_file)

        self.engine.shutdown()
        logger.info("Server stopped")

    def is_running(self) -> bool:
        return self._running

    def wait(self) -> None:
        try:
            while self._running:
                self._shutdown_event.wait(1)
        except KeyboardInterrupt:
            self.stop()


def create_and_start(config_path: Optional[str] = None) -> LocalDNSServer:
    from termux.resolver.config import get_config as gc
    gc(config_path)
    engine = DNSEngine()
    server = LocalDNSServer(engine)
    server.start()
    return server
