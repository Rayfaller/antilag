# -*- coding: utf-8 -*-
"""
Local DNS VPN - Diagnostic System
Comprehensive diagnostics for the complete system.
"""

import time
import socket
import os
import sys
from typing import Dict, List, Any

from termux.resolver.utils import get_logger, Timer, is_valid_ip, format_duration
from termux.resolver.config import get_config

logger = get_logger()

class DiagnosticSystem:
    def __init__(self):
        self.config = get_config()
        self.issues: List[str] = []
        self.warnings: List[str] = []
        self.checks: Dict[str, bool] = {}

    def run_all(self) -> Dict[str, Any]:
        print("\n" + "=" * 60)
        print("  LOCAL DNS VPN - DIAGNÓSTICO COMPLETO")
        print("=" * 60 + "\n")

        self._check_termux()
        self._check_resolver()
        self._check_cache()
        self._check_upstreams()
        self._check_internet()
        self._check_vpn()
        self._check_dns_interception()
        self._check_local_comm()

        self._print_summary()
        return {"checks": self.checks, "issues": self.issues, "warnings": self.warnings}

    def _check_termux(self) -> None:
        print("[1/8] Verificando Termux...")
        is_termux = os.path.exists("/data/data/com.termux/files/usr/bin")
        self.checks["termux"] = is_termux
        if is_termux:
            print("  [✓] Ambiente Termux detectado")
        else:
            print("  [✗] Ambiente Termux NÃO detectado")
            self.warnings.append("Não está rodando no Termux - algumas funcionalidades podem ser limitadas")

    def _check_resolver(self) -> None:
        print("[2/8] Verificando resolver...")
        try:
            from termux.resolver.engine import DNSEngine
            engine = DNSEngine()
            print("  [✓] Resolver inicializado")
            self.checks["resolver"] = True
        except Exception as e:
            print(f"  [✗] Erro no resolver: {e}")
            self.checks["resolver"] = False
            self.issues.append(f"Resolver não inicializou: {e}")

    def _check_cache(self) -> None:
        print("[3/8] Verificando cache...")
        try:
            from termux.resolver.cache import DNSCache
            cache = DNSCache(max_size=100)
            cache.put("test.com", 1, b"test", 300)
            result = cache.get("test.com", 1)
            if result == b"test":
                print("  [✓] Cache funcionando")
                self.checks["cache"] = True
            else:
                print("  [✗] Cache não retornou valor correto")
                self.checks["cache"] = False
        except Exception as e:
            print(f"  [✗] Erro no cache: {e}")
            self.checks["cache"] = False

    def _check_upstreams(self) -> None:
        print("[4/8] Testando upstreams...")
        servers = self.config.get_upstream_servers()
        all_ok = True
        for srv in servers:
            name = srv["name"]
            addr = srv["addresses"][0]
            try:
                with Timer() as t:
                    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
                    sock.settimeout(3)
                    # Simple DNS query
                    import struct, random
                    tid = random.randint(0, 65535)
                    query = struct.pack('!HHHHHH', tid, 0x0100, 1, 0, 0, 0)
                    query += b'\x07example\x03com\x00\x00\x01\x00\x01'
                    sock.sendto(query, (addr, srv.get("port", 53)))
                    sock.recvfrom(512)
                    sock.close()
                print(f"  [✓] {name} ({addr}): {t.milliseconds:.1f}ms")
            except Exception as e:
                print(f"  [✗] {name} ({addr}): {e}")
                all_ok = False
        self.checks["upstreams"] = all_ok
        if not all_ok:
            self.warnings.append("Alguns upstreams não responderam - fallback será necessário")

    def _check_internet(self) -> None:
        print("[5/8] Verificando internet...")
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            sock.settimeout(5)
            sock.connect(("1.1.1.1", 53))
            sock.close()
            print("  [✓] Conectividade OK")
            self.checks["internet"] = True
        except Exception as e:
            print(f"  [✗] Sem internet: {e}")
            self.checks["internet"] = False
            self.issues.append("Sem conectividade com a internet")

    def _check_vpn(self) -> None:
        print("[6/8] Verificando VPN...")
        # Check if VPN interface exists (Linux/Android)
        try:
            import subprocess
            result = subprocess.run(["ip", "addr", "show"], capture_output=True, text=True)
            if "tun" in result.stdout.lower():
                print("  [✓] Interface TUN detectada")
                self.checks["vpn"] = True
            else:
                print("  [⚠] Interface TUN não detectada (VPN pode não estar ativa)")
                self.checks["vpn"] = False
                self.warnings.append("VPN não parece estar ativa no momento")
        except Exception:
            print("  [⚠] Não foi possível verificar interface VPN")
            self.checks["vpn"] = False

    def _check_dns_interception(self) -> None:
        print("[7/8] Verificando interceptação DNS...")
        listen_port = self.config.get("general.listen_port", 5353)
        try:
            sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            sock.bind(("127.0.0.1", listen_port))
            sock.close()
            print(f"  [✓] Porta {listen_port} disponível para resolver")
            self.checks["dns_interception"] = True
        except socket.error:
            print(f"  [⚠] Porta {listen_port} em uso - resolver pode já estar rodando")
            self.checks["dns_interception"] = True  # This is actually OK

    def _check_local_comm(self) -> None:
        print("[8/8] Verificando comunicação local...")
        unix_path = self.config.get("android.termux_socket_path", "")
        if os.path.exists(unix_path):
            print(f"  [✓] Socket Unix existe: {unix_path}")
            self.checks["local_comm"] = True
        else:
            print(f"  [⚠] Socket Unix não encontrado: {unix_path}")
            print("  (Isso é normal se o resolver não estiver rodando)")
            self.checks["local_comm"] = False

    def _print_summary(self) -> None:
        print("\n" + "=" * 60)
        print("  RESUMO")
        print("=" * 60)
        passed = sum(1 for v in self.checks.values() if v)
        total = len(self.checks)
        print(f"\n  Testes passados: {passed}/{total}")

        if not self.issues and not self.warnings:
            print("\n  ✅ Todos os testes passaram!")
        else:
            if self.issues:
                print(f"\n  ❌ {len(self.issues)} PROBLEMA(S):")
                for i, issue in enumerate(self.issues, 1):
                    print(f"     {i}. {issue}")
            if self.warnings:
                print(f"\n  ⚠️  {len(self.warnings)} AVISO(S):")
                for i, warning in enumerate(self.warnings, 1):
                    print(f"     {i}. {warning}")
        print("=" * 60 + "\n")


def run_diagnose() -> None:
    diag = DiagnosticSystem()
    diag.run_all()
