# -*- coding: utf-8 -*-
"""
Local DNS VPN - CLI
Command-line interface for the complete system.
"""

import sys
import os
import argparse
import time
import json
import signal

from termux.resolver.utils import get_logger, read_pid_file, is_process_running, remove_pid_file, format_duration
from termux.resolver.config import get_config, reload_config
from termux.resolver.engine import DNSEngine
from termux.resolver.server import LocalDNSServer, create_and_start
from termux.resolver.diagnose import DiagnosticSystem
from termux.resolver.benchmark import BenchmarkSystem

logger = get_logger()

class DNSCLI:
    def __init__(self):
        self.parser = self._create_parser()

    def _create_parser(self) -> argparse.ArgumentParser:
        parser = argparse.ArgumentParser(
            prog='dns',
            description='Local DNS VPN - Resolver DNS local para Android/Termux',
            formatter_class=argparse.RawDescriptionHelpFormatter,
            epilog="""
Comandos:
  start       Iniciar o resolver DNS
  stop        Parar o resolver
  restart     Reiniciar o resolver
  status      Mostrar status atual
  benchmark   Executar benchmark dos upstreams
  stats       Mostrar estatísticas detalhadas
  cache       Mostrar estatísticas do cache
  clear-cache Limpar cache DNS
  upstreams   Mostrar status dos upstreams
  diagnose    Executar diagnóstico completo
  config      Mostrar configuração atual
  logs        Mostrar logs recentes
            """
        )
        parser.add_argument('command', choices=[
            'start', 'stop', 'restart', 'status', 'benchmark', 'stats',
            'cache', 'clear-cache', 'upstreams', 'diagnose', 'config', 'logs'
        ])
        parser.add_argument('--config', '-c', help='Arquivo de configuração')
        parser.add_argument('--foreground', '-f', action='store_true', help='Primeiro plano')
        parser.add_argument('--port', '-p', type=int, help='Porta UDP')
        parser.add_argument('--mode', '-m', choices=['fast', 'balanced', 'stable'], help='Modo')
        return parser

    def run(self, args=None) -> int:
        parsed = self.parser.parse_args(args)
        if parsed.config:
            get_config(parsed.config)
        if parsed.mode:
            get_config().set("upstream.selection_mode", parsed.mode)
        if parsed.port:
            get_config().set("general.listen_port", parsed.port)

        cmds = {
            'start': self.cmd_start,
            'stop': self.cmd_stop,
            'restart': self.cmd_restart,
            'status': self.cmd_status,
            'benchmark': self.cmd_benchmark,
            'stats': self.cmd_stats,
            'cache': self.cmd_cache,
            'clear-cache': self.cmd_clear_cache,
            'upstreams': self.cmd_upstreams,
            'diagnose': self.cmd_diagnose,
            'config': self.cmd_config,
            'logs': self.cmd_logs,
        }
        return cmds[parsed.command](parsed)

    def cmd_start(self, args) -> int:
        pid_file = get_config().get("general.pid_file", "logs/local_dns.pid")
        pid = read_pid_file(pid_file)
        if pid and is_process_running(pid):
            print(f"Já está rodando (PID: {pid})")
            return 1

        print("Iniciando Local DNS VPN...")
        try:
            server = create_and_start(args.config)
            if args.foreground:
                print(f"Rodando em {server.udp_addr}:{server.udp_port}")
                print("Pressione Ctrl+C para parar")
                server.wait()
            else:
                print(f"Iniciado em {server.udp_addr}:{server.udp_port}")
                print(f"PID: {read_pid_file(pid_file)}")
                print("Use 'dns stop' para parar")
        except Exception as e:
            print(f"Erro: {e}")
            return 1
        return 0

    def cmd_stop(self, args) -> int:
        pid_file = get_config().get("general.pid_file", "logs/local_dns.pid")
        pid = read_pid_file(pid_file)
        if not pid:
            print("Não está rodando")
            return 1
        if not is_process_running(pid):
            remove_pid_file(pid_file)
            print("Já estava parado")
            return 1

        print(f"Parando (PID: {pid})...")
        try:
            os.kill(pid, signal.SIGTERM)
            for _ in range(10):
                if not is_process_running(pid):
                    break
                time.sleep(0.5)
            if is_process_running(pid):
                os.kill(pid, signal.SIGKILL)
            remove_pid_file(pid_file)
            print("Parado")
        except Exception as e:
            print(f"Erro: {e}")
            return 1
        return 0

    def cmd_restart(self, args) -> int:
        self.cmd_stop(args)
        time.sleep(1)
        return self.cmd_start(args)

    def cmd_status(self, args) -> int:
        pid_file = get_config().get("general.pid_file", "logs/local_dns.pid")
        pid = read_pid_file(pid_file)

        print("=" * 56)
        print("  LOCAL DNS VPN - STATUS")
        print("=" * 56)

        if pid and is_process_running(pid):
            print(f"  Status:    🟢 ATIVO (PID: {pid})")
        else:
            print(f"  Status:    🔴 INATIVO")

        mode = get_config().get("upstream.selection_mode", "balanced")
        port = get_config().get("general.listen_port", 5353)
        print(f"  Modo:      {mode.upper()}")
        print(f"  Porta:     {port}")
        print(f"  Cache:     {'Ativado' if get_config().get('cache.enabled', True) else 'Desativado'}")
        print("=" * 56)

        try:
            engine = DNSEngine()
            stats = engine.get_stats()

            print(f"\n  Uptime:        {stats['uptime_formatted']}")
            print(f"  Consultas:     {stats['total_queries']}")
            print(f"  Falhas:        {stats['total_failures']} ({stats['failure_rate']}%)")
            print(f"  Cache HIT:     {stats['cache']['hit_rate']}%")
            print(f"  Cache MISS:    {stats['cache']['miss_rate']}%")
            print(f"  Entradas:      {stats['cache']['entries']}")
            print(f"  Upstream:      {stats['upstream']['primary'] or 'N/A'}")

            if stats['upstream']['servers']:
                primary = stats['upstream']['primary']
                if primary and primary in stats['upstream']['servers']:
                    lat = stats['upstream']['servers'][primary]['latency_avg_ms']
                    print(f"  Latência:      {lat} ms")

            print(f"  Coalesced:     {stats['coalescing']['coalesced_queries']}")
            print("=" * 56)
        except Exception as e:
            print(f"\n  (Stats não disponíveis: {e})")
        return 0

    def cmd_benchmark(self, args) -> int:
        print("Executando benchmark...")
        try:
            engine = DNSEngine()
            bench = BenchmarkSystem(engine.upstream_manager)
            results = bench.run_benchmark(force=True)

            print("\n" + "=" * 56)
            print("  RESULTADOS DO BENCHMARK")
            print("=" * 56)
            print(f"  {'Servidor':<15} {'Média':<10} {'Mediana':<10} {'P95':<10} {'Sucesso':<10} {'Score':<8}")
            print("  " + "-" * 60)

            for name, result in results.items():
                d = result.to_dict()
                avg = f"{d['latency_avg_ms']}ms"
                med = f"{d['latency_median_ms']}ms"
                p95 = f"{d['latency_p95_ms']}ms"
                suc = f"{d['success_rate']}%"
                scr = f"{result.calculate_score({}, {}):.0f}"
                print(f"  {name:<15} {avg:<10} {med:<10} {p95:<10} {suc:<10} {scr:<8}")
            print("=" * 56)
        except Exception as e:
            print(f"Erro: {e}")
            return 1
        return 0

    def cmd_stats(self, args) -> int:
        try:
            engine = DNSEngine()
            print(json.dumps(engine.get_stats(), indent=2, default=str))
        except Exception as e:
            print(f"Erro: {e}")
            return 1
        return 0

    def cmd_cache(self, args) -> int:
        try:
            engine = DNSEngine()
            stats = engine.cache.get_stats()
            print("=" * 40)
            print("  CACHE DNS")
            print("=" * 40)
            print(f"  Entradas:      {stats['entries']}/{stats['max_size']}")
            print(f"  Cache HIT:     {stats['hit_rate']}%")
            print(f"  Cache MISS:    {stats['miss_rate']}%")
            print(f"  Evicções:      {stats['evictions']}")
            print(f"  Expirações:    {stats['expirations']}")
            print(f"  Memória est.:  {stats['memory_estimate_kb']} KB")
            print("=" * 40)
        except Exception as e:
            print(f"Erro: {e}")
            return 1
        return 0

    def cmd_clear_cache(self, args) -> int:
        try:
            engine = DNSEngine()
            count = engine.cache.clear()
            print(f"Cache limpo: {count} entradas removidas")
        except Exception as e:
            print(f"Erro: {e}")
            return 1
        return 0

    def cmd_upstreams(self, args) -> int:
        try:
            engine = DNSEngine()
            stats = engine.upstream_manager.get_stats()
            print("=" * 70)
            print("  UPSTREAMS")
            print("=" * 70)
            print(f"  Primário: {stats['primary'] or 'N/A'}")
            print(f"  Disponíveis: {stats['available']}/{stats['total']}")
            print()
            print(f"  {'Nome':<15} {'Latência':<12} {'Sucesso':<10} {'Estado':<12} {'Score':<8}")
            print("  " + "-" * 60)
            for name, s in stats['servers'].items():
                lat = f"{s['latency_avg_ms']}ms" if s['latency_avg_ms'] != float('inf') else "N/A"
                marker = "→ " if name == stats['primary'] else "  "
                print(f"  {marker}{name:<13} {lat:<12} {s['success_rate']:<10} {s['circuit_state']:<12} {s['score']:<8}")
            print("=" * 70)
        except Exception as e:
            print(f"Erro: {e}")
            return 1
        return 0

    def cmd_diagnose(self, args) -> int:
        diag = DiagnosticSystem()
        diag.run_all()
        return 0

    def cmd_config(self, args) -> int:
        print(json.dumps(get_config().data, indent=2, ensure_ascii=False))
        return 0

    def cmd_logs(self, args) -> int:
        log_file = get_config().get("general.log_file", "logs/local_dns.log")
        if not os.path.exists(log_file):
            print(f"Log não encontrado: {log_file}")
            return 1
        try:
            with open(log_file, 'r') as f:
                lines = f.readlines()
                for line in lines[-50:]:
                    print(line.rstrip())
        except Exception as e:
            print(f"Erro: {e}")
            return 1
        return 0


def main():
    cli = DNSCLI()
    sys.exit(cli.run())

if __name__ == '__main__':
    main()
