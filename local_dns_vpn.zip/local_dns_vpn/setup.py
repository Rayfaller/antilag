from setuptools import setup, find_packages

setup(
    name="local-dns-vpn",
    version="1.0.0",
    description="Local DNS resolver with Android VPN integration",
    packages=find_packages(),
    install_requires=["dnspython>=2.3.0", "psutil>=5.9.0"],
    extras_require={"dev": ["pytest>=7.3.0"]},
    python_requires=">=3.8",
)
