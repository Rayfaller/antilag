# Arquitetura

## Visão Geral

```
┌─────────────────────────────────────────────────────────────┐
│                      ANDROID APPS                           │
└──────────────────────┬──────────────────────────────────────┘
                       │ DNS Query (UDP 53)
                       ▼
┌─────────────────────────────────────────────────────────────┐
│              VPN SERVICE (LocalDnsVpnService)               │
│              Intercepta pacotes DNS na TUN                  │
│              addDisallowedApplication(Termux)               │
└──────────────────────┬──────────────────────────────────────┘
                       │ Encaminha DNS data
                       ▼
┌─────────────────────────────────────────────────────────────┐
│              ANDROID APP (DnsForwarder)                     │
│              UDP 127.0.0.1:5353 ou Unix Socket              │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│              TERMUX RESOLVER (DNSEngine)                    │
│  ┌─────────┐  ┌──────────┐  ┌──────────────────────────┐  │
│  │  CACHE  │  │COALESCING│  │      UPSTREAM MGR        │  │
│  │get/put  │──│dedup     │──│circuit breaker + health  │  │
│  │LRU+TTL  │  │50ms win  │  │benchmark + scoring       │  │
│  └─────────┘  └──────────┘  └──────────────────────────┘  │
└──────────────────────┬──────────────────────────────────────┘
                       │
                       ▼
┌─────────────────────────────────────────────────────────────┐
│              UPSTREAM DNS SERVERS                           │
│    ┌──────────┐  ┌──────────┐  ┌──────────┐              │
│    │Cloudflare│  │  Google  │  │  Quad9   │              │
│    │1.1.1.1   │  │8.8.8.8   │  │9.9.9.9   │              │
│    └──────────┘  └──────────┘  └──────────┘              │
└─────────────────────────────────────────────────────────────┘
```

## Componentes Termux

### DNSEngine
- Pipeline: parse -> cache -> coalescing -> upstream -> fallback
- Suporta A, AAAA, CNAME, MX, TXT, NXDOMAIN, SERVFAIL
- Thread-safe com RLock

### DNSCache
- OrderedDict para LRU
- TTL respeitado com clamping
- Cleanup thread a cada 60s
- Estatísticas HIT/MISS

### QueryCoalescer
- Janela de 50ms
- Máximo 100 waiters
- 1 upstream query para N simultâneas

### UpstreamManager
- Circuit breaker: CLOSED → OPEN → HALF_OPEN → CLOSED
- Health checks a cada 60s
- Scoring: latência + sucesso + estabilidade

### BenchmarkSystem
- Domínios reais: google.com, github.com, etc.
- Métricas: avg, median, p95, min, max, std
- Intervalo: 10 minutos (configurável)

## Componentes Android

### LocalDnsVpnService
- VpnService com Builder
- Interface TUN: 10.0.0.1/24
- DNS virtual: 10.0.0.2
- addDisallowedApplication("com.termux") - **CRÍTICO para evitar loop**
- Foreground service com notificação

### DnsInterceptor
- Lê pacotes da interface TUN
- Filtra apenas DNS (UDP porta 53)
- Extrai payload DNS
- Reconstrói pacote resposta

### DnsForwarder
- Tenta Unix socket primeiro
- Fallback para UDP 127.0.0.1:5353
- Timeout: 5 segundos

## Comunicação App ↔ Termux

**Protocolo Unix Socket:**
```
[1 byte: tipo][4 bytes: tamanho][dados]

Tipos:
  0x01 = DNS Query
  0x02 = Stats Request
  0x03 = Ping
```

**Fallback UDP:**
- Endereço: 127.0.0.1
- Porta: 5353 (não-privilegiada)

## Prevenção de Loop

```java
// CRÍTICO: Sem isso, o tráfego DNS do resolver volta para a VPN
builder.addDisallowedApplication("com.termux");
builder.addDisallowedApplication(getPackageName());
```

Isso garante que:
- O resolver no Termux não envie queries pela VPN
- O próprio app Android não crie loop
- O tráfego DNS vai direto para upstream via rede normal

## Threading

- **Main**: UI e VpnService
- **DNS-Interceptor**: leitura TUN
- **UDP Server**: socket.listen()
- **Unix Server**: socket.accept()
- **Cache Cleanup**: daemon, 60s
- **Health Check**: daemon, 60s
- **Benchmark**: daemon, 600s

## Memória

- Cache: ~5000 entradas × 256 bytes ≈ 1.25MB
- Histórico latência: 100 floats × 8 bytes = 800 bytes
- Total estimado: < 5MB
