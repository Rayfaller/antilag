# Compilando o App Android

## Requisitos

- Android Studio Hedgehog (2023.1.1) ou superior
- JDK 17
- Android SDK 34
- Gradle 8.2

## Passos

1. **Abrir projeto**
   ```
   File -> Open -> android/
   ```

2. **Sincronizar Gradle**
   ```
   Click "Sync Now" na barra amarela
   ```

3. **Compilar Debug**
   ```
   Build -> Make Project (Ctrl+F9)
   ```

4. **Gerar APK**
   ```
   Build -> Build Bundle(s) / APK(s) -> Build APK(s)
   ```

5. **Instalar no dispositivo**
   ```
   Run -> Run 'app' (Shift+F10)
   ```

## Via linha de comando

```bash
cd android
./gradlew assembleDebug

# Instalar
adb install app/build/outputs/apk/debug/app-debug.apk
```

## Release

```bash
# Criar keystore
keytool -genkey -v -keystore localdns.keystore -alias localdns -keyalg RSA -validity 10000

# Compilar release
./gradlew assembleRelease
```

## Solução de Problemas

**"Gradle sync failed"**
- Verifique conexão com internet
- File -> Invalidate Caches / Restart

**"Minimum SDK not met"**
- Verifique que minSdk é 26 no build.gradle

**"VPN permission denied"**
- Normal na primeira execução
- O app solicitará automaticamente
