# Solução de Problemas

## Problemas Comuns

### "VPN não inicia"

**Causa**: Permissão VPN não concedida.
**Solução**: Toque em ATIVAR VPN e aceite o diálogo do Android.

### "DNS não responde"

**Verificar**:
```bash
dns status  # Resolver está rodando?
dns diagnose  # Upstreams respondem?
```

**Causas**:
1. Resolver não iniciado: `dns start`
2. Termux sem internet: verifique Wi-Fi/dados
3. Upstream bloqueado: teste com `dns benchmark`

### "Loop infinito"

**Sintoma**: CPU 100%, logs infinitos de DNS.
**Causa**: Termux não excluído da VPN.
**Verificação**:
```java
// Deve estar no código:
builder.addDisallowedApplication("com.termux");
```

**Solução**: Reinstale o app Android com código atualizado.

### "App Android não conecta ao Termux"

**Verificar**:
1. Resolver rodando: `dns status`
2. Porta 5353 aberta: `lsof -i :5353`
3. Socket existe: `ls /data/data/com.termux/files/usr/tmp/local_dns.sock`

**Solução**:
```bash
# Reiniciar resolver
dns restart

# Verificar permissões do socket
chmod 777 /data/data/com.termux/files/usr/tmp/local_dns.sock
```

### "Alta latência"

**Verificar modo**:
```bash
dns status  # Qual modo?
dns benchmark  # Quais latências?
```

**Ajustes**:
```bash
dns start --mode fast  # Prioriza velocidade
```

### "Bateria drenando"

**Causas**:
- Benchmark muito frequente
- Cache muito grande
- Logs excessivos

**Solução**:
```json
{
  "benchmark": {
    "benchmark_interval": 1800
  },
  "cache": {
    "max_size": 2000
  },
  "general": {
    "log_level": "WARNING"
  }
}
```

### "Cache não funciona"

**Verificar**:
```bash
dns cache
```

**Causas**:
- Cache desativado
- TTL muito baixo nos registros
- Cache cheio

## Coletar Informações

```bash
# Diagnóstico completo
dns diagnose > diag.txt

# Estatísticas
dns stats > stats.txt

# Logs
dns logs > logs.txt

# Enviar para suporte:
# diag.txt + stats.txt + logs.txt
```

## Limitações Conhecidas

1. **Android 13+**: Unix domain sockets requerem API 33+
   - **Alternativa**: Usamos TCP localhost como fallback

2. **Termux na Play Store**: Desatualizado, use F-Droid

3. **Bateria**: Android pode matar o Termux em segundo plano
   - **Solução**: `termux-wake-lock` + sem restrições de bateria

4. **IPv6**: Suporte parcial no Android app
   - **Status**: IPv4 funciona perfeitamente, IPv6 em desenvolvimento
