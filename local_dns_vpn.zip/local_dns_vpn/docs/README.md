# Local DNS VPN

Sistema completo de DNS local de baixa latência para Android, integrado ao Termux + VPN local. **Sem domínio, sem VPS, sem root.**

## ⚠️ Aviso Importante

**Este sistema NÃO aumenta a velocidade contratada da sua internet.**

O que melhora:
- ✅ Tempo de resolução DNS
- ✅ Cache de consultas frequentes
- ✅ Seleção automática do melhor upstream
- ✅ Menor latência de início de conexões
- ✅ Estabilidade e fallback automático

O que NÃO melhora:
- ❌ Velocidade de download/upload
- ❌ Latência de jogos (depende de rota)
- ❌ Congestionamento de rede

## Arquitetura

```
ANDROID APPS
     ↓
VPN LOCAL (VpnService) - intercepta DNS
     ↓
DNS VIRTUAL (10.0.0.2)
     ↓
ANDROID APP encaminha para Termux
     ↓
RESOLVER LOCAL (127.0.0.1:5353)
     ↓
CACHE DNS
     ↓
UPSTREAM SELECTION (benchmark real)
     ↓
Cloudflare / Google / Quad9
     ↓
INTERNET
```

## Componentes

1. **Termux Resolver** (`termux/resolver/`): Motor DNS em Python
2. **Android App** (`android/app/`): VPN com VpnService
3. **Comunicação**: UDP localhost + Unix socket

## Instalação

### 1. Termux (F-Droid)

```bash
# Instalar Python
pkg update && pkg install python git

# Clonar projeto
cd ~
git clone <repo>
cd local_dns_vpn

# Instalar
bash termux/scripts/install.sh

# Iniciar resolver
dns start
```

### 2. Android App

```bash
cd android
./gradlew assembleDebug
```

Ou instale o APK pré-compilado.

### 3. Uso

1. Abra o app Android
2. Toque em **ATIVAR VPN**
3. Conceda permissão VPN
4. Pronto! DNS interceptado

## Comandos Termux

| Comando | Descrição |
|---------|-----------|
| `dns start` | Iniciar resolver |
| `dns stop` | Parar resolver |
| `dns restart` | Reiniciar |
| `dns status` | Status atual |
| `dns benchmark` | Benchmark upstreams |
| `dns stats` | Estatísticas |
| `dns cache` | Cache stats |
| `dns clear-cache` | Limpar cache |
| `dns upstreams` | Status upstreams |
| `dns diagnose` | Diagnóstico |
| `dns config` | Ver config |
| `dns logs` | Ver logs |

## Modos

- **FAST**: Mínima latência
- **BALANCED**: Equilibrado (padrão)
- **STABLE**: Máxima confiabilidade

```bash
dns start --mode fast
```

## Características

- 🚀 **Benchmark real** - medições reais, não simuladas
- 💾 **Cache com TTL** - respeita TTL, limpeza automática
- 🔄 **Request Coalescing** - 100 apps = 1 consulta upstream
- 🛡️ **Circuit Breaker** - proteção contra servidores ruins
- 📊 **Estatísticas** - HIT/MISS, latência, uptime
- 🔋 **Economia de bateria** - intervalos configuráveis
- 🔒 **Loop prevention** - `addDisallowedApplication(Termux)`
- 🌐 **IPv4 + IPv6** - A, AAAA, CNAME, MX, TXT

## Segurança

- Apenas localhost (127.0.0.1)
- Sem acesso externo
- Sem logging de domínios por padrão
- Validação de pacotes DNS
- Rate limiting

## Licença

MIT License
