# Configuração do Termux

## Instalação do Termux

**IMPORTANTE:** Use o Termux do F-Droid, não da Play Store.

1. Baixe F-Droid: https://f-droid.org/
2. Instale Termux e Termux:Boot

## Configuração Inicial

```bash
# Atualizar repositórios
pkg update

# Instalar essenciais
pkg install python git curl

# Verificar Python
python3 --version  # Deve ser 3.8+
```

## Instalando o Local DNS

```bash
cd ~
# Baixe o projeto (git clone ou unzip)

cd local_dns_vpn
bash termux/scripts/install.sh
```

## Comandos Diários

```bash
# Iniciar
dns start

# Ver status
dns status

# Benchmark manual
dns benchmark

# Diagnóstico
dns diagnose

# Parar
dns stop
```

## Permissões do Android

O Termux precisa de:
- **Storage** (para logs e config)
- **Run in background** (para manter resolver ativo)

Configure em:
```
Configurações do Android -> Apps -> Termux -> Bateria -> Sem restrições
```

## Inicialização Automática

Com Termux:Boot instalado:
```bash
# O script já foi criado em:
ls ~/.termux/boot/

# Para testar:
termux-wake-lock
bash ~/.termux/boot/start-local-dns
```

## Solução de Problemas

**"Permission denied"**
```bash
chmod +x ~/.local/bin/dns
```

**"Module not found"**
```bash
export PYTHONPATH="$HOME/.local_dns_vpn:$PYTHONPATH"
```

**"Port already in use"**
```bash
# Verificar processo
lsof -i :5353
# Ou usar outra porta
dns start --port 5354
```
