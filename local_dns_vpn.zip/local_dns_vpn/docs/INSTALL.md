# Guia de Instalação

## Requisitos

- Android 9+ (API 26+)
- Termux 0.118+ (instale via F-Droid, não Play Store)
- 100MB espaço livre
- Python 3.8+

## Passo a Passo

### Termux

```bash
# 1. Atualizar
pkg update && pkg upgrade

# 2. Instalar dependências
pkg install python git

# 3. Clonar projeto
cd ~
git clone https://github.com/seu-repo/local_dns_vpn.git
cd local_dns_vpn

# 4. Instalar
bash termux/scripts/install.sh

# 5. Verificar
dns diagnose
```

### Android App

**Opção 1: Compilar**
```bash
cd android
./gradlew assembleDebug
# APK em: app/build/outputs/apk/debug/app-debug.apk
```

**Opção 2: Instalar APK**
```bash
adb install app-debug.apk
```

### Inicialização Automática (Termux:Boot)

```bash
# O instalador já criou:
# ~/.termux/boot/start-local-dns

# Para ativar:
termux-wake-lock
```

## Configuração

Edite `~/.local_dns_vpn/config/config.json`:

```json
{
  "upstream": {
    "selection_mode": "balanced"
  },
  "cache": {
    "max_size": 5000
  }
}
```

## Desinstalação

```bash
bash ~/.local_dns_vpn/uninstall.sh
```

Ou manualmente:
```bash
dns stop
rm -rf ~/.local_dns_vpn
rm -f ~/.local/bin/dns
rm -f ~/.termux/boot/start-local-dns
```
