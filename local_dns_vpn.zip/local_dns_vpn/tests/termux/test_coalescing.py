import time
import threading
from termux.resolver.coalescing import QueryCoalescer

class TestCoalescing:
    def test_coalesce(self):
        c = QueryCoalescer(window_ms=100)
        results = []

        def callback(resp):
            results.append(resp)

        def execute(domain, rtype, data):
            time.sleep(0.01)
            c.resolve_pending(domain, rtype, b"response")

        # First query should execute
        assert not c.coalesce_or_execute("google.com", 1, b"q", execute, callback)

        # Second identical query should coalesce
        assert c.coalesce_or_execute("google.com", 1, b"q", execute, callback)

    def test_stats(self):
        c = QueryCoalescer()
        s = c.get_stats()
        assert "coalesced_queries" in s
