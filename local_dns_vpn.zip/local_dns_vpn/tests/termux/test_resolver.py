import pytest
from termux.resolver.engine import DNSEngine

class TestEngine:
    def test_parse_query(self):
        e = DNSEngine()
        query = bytes.fromhex(
            '000001000001000000000000' +
            '07' + '6578616d706c65' +
            '03' + '636f6d' +
            '0000010001'
        )
        domain, rtype = e._parse_query(query)
        assert domain == "example.com"
        assert rtype == 1

    def test_build_error(self):
        e = DNSEngine()
        query = bytes.fromhex('12340100000100000000')
        resp = e._build_error(query, rcode=2)
        assert len(resp) >= 12
        tid = int.from_bytes(resp[:2], 'big')
        assert tid == 0x1234
        flags = int.from_bytes(resp[2:4], 'big')
        assert flags & 0x8000
        assert (flags & 0x000F) == 2
