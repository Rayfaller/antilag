import pytest
from termux.resolver.upstream import UpstreamServer, UpstreamManager, CircuitState

class TestUpstream:
    def test_success(self):
        s = UpstreamServer(name="Test", addresses=["1.1.1.1"])
        s.record_success(20.0)
        assert s.total_queries == 1
        assert s.success_count == 1
        assert s.average_latency == 20.0

    def test_failure(self):
        s = UpstreamServer(name="Test", addresses=["1.1.1.1"])
        s.record_failure(is_timeout=True)
        assert s.failure_count == 1
        assert s.timeout_count == 1

    def test_circuit_breaker(self):
        s = UpstreamServer(name="Test", addresses=["1.1.1.1"])
        for _ in range(5):
            s.record_failure()
        assert s.circuit_state == CircuitState.OPEN
        assert not s.is_available

    def test_manager_init(self):
        m = UpstreamManager()
        assert len(m.get_all_servers()) >= 3
