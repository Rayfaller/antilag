import pytest
from termux.resolver.benchmark import BenchmarkResult

class TestBenchmark:
    def test_latency(self):
        r = BenchmarkResult("Test")
        for lat in [10, 20, 30, 40, 50]:
            r.add_result(lat)
        assert r.average_latency == 30.0
        assert r.median_latency == 30.0
        assert r.min_latency == 10.0
        assert r.max_latency == 50.0

    def test_success_rate(self):
        r = BenchmarkResult("Test")
        r.add_result(10.0)
        r.add_result(20.0)
        r.add_result(None, is_timeout=True)
        assert r.success_rate == 2/3

    def test_score(self):
        r = BenchmarkResult("Test")
        r.add_result(20.0)
        r.add_result(25.0)
        weights = {"latency_avg": 0.4, "latency_p95": 0.2, "success_rate": 0.3, "stability": 0.1}
        penalties = {"timeout": 100, "failure": 50, "instability": 25}
        score = r.calculate_score(weights, penalties)
        assert score > 0
