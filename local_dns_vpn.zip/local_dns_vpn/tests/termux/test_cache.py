import time
import pytest
from termux.resolver.cache import DNSCache

class TestCache:
    def test_put_get(self):
        c = DNSCache(max_size=100)
        c.put("example.com", 1, b"resp", 300)
        assert c.get("example.com", 1) == b"resp"

    def test_miss(self):
        c = DNSCache(max_size=100)
        assert c.get("missing.com", 1) is None

    def test_ttl_expiration(self):
        c = DNSCache(max_size=100, min_ttl=1)
        c.put("test.com", 1, b"data", 1)
        assert c.get("test.com", 1) == b"data"
        time.sleep(1.1)
        assert c.get("test.com", 1) is None

    def test_stats(self):
        c = DNSCache(max_size=100)
        c.put("a.com", 1, b"a", 300)
        c.get("a.com", 1)
        c.get("a.com", 1)
        c.get("x.com", 1)
        s = c.get_stats()
        assert s["hits"] == 2
        assert s["misses"] == 1

    def test_max_size(self):
        c = DNSCache(max_size=3)
        c.put("a", 1, b"a", 300)
        c.put("b", 1, b"b", 300)
        c.put("c", 1, b"c", 300)
        c.put("d", 1, b"d", 300)
        assert c.size == 3

    def test_clear(self):
        c = DNSCache(max_size=100)
        c.put("x", 1, b"x", 300)
        assert c.clear() == 1
        assert c.size == 0
