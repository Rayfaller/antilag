package com.localdns.dns;
import com.localdns.network.TermuxConnector;
import com.localdns.util.Constants;
import com.localdns.util.Logger;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class DnsForwarder {
    private TermuxConnector connector;
    private DatagramSocket udpSocket;

    public DnsForwarder() {
        this.connector = new TermuxConnector();
        try {
            this.udpSocket = new DatagramSocket();
            this.udpSocket.setSoTimeout(Constants.DNS_TIMEOUT);
        } catch (Exception e) {
            Logger.e("Failed to create UDP socket", e);
        }
    }

    public byte[] forward(byte[] dnsQuery) {
        // Try Unix socket first (most efficient)
        byte[] response = connector.sendQuery(dnsQuery);
        if (response != null && response.length > 0) {
            return response;
        }

        // Fallback to UDP localhost
        return forwardViaUdp(dnsQuery);
    }

    private byte[] forwardViaUdp(byte[] query) {
        if (udpSocket == null) return null;
        try {
            InetAddress addr = InetAddress.getByName(Constants.TERMUX_RESOLVER_HOST);
            DatagramPacket request = new DatagramPacket(query, query.length, addr, Constants.TERMUX_PORT);
            udpSocket.send(request);

            byte[] buffer = new byte[Constants.DNS_MAX_SIZE];
            DatagramPacket response = new DatagramPacket(buffer, buffer.length);
            udpSocket.receive(response);

            byte[] result = new byte[response.getLength()];
            System.arraycopy(buffer, 0, result, 0, response.getLength());
            return result;
        } catch (Exception e) {
            Logger.e("UDP forward error", e);
            return null;
        }
    }

    public void close() {
        if (udpSocket != null && !udpSocket.isClosed()) {
            udpSocket.close();
        }
        connector.close();
    }
}
