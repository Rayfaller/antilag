package com.localdns.ui;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.localdns.R;
import com.localdns.util.Logger;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;

public class LogsFragment extends Fragment {
    private TextView logsText;
    private Handler handler;
    private Runnable refreshRunnable;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_logs, container, false);
        logsText = view.findViewById(R.id.logsText);
        handler = new Handler(Looper.getMainLooper());

        refreshRunnable = new Runnable() {
            @Override
            public void run() {
                refreshLogs();
                handler.postDelayed(this, 3000);
            }
        };

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        refreshLogs();
        handler.post(refreshRunnable);
    }

    @Override
    public void onPause() {
        super.onPause();
        handler.removeCallbacks(refreshRunnable);
    }

    private void refreshLogs() {
        try {
            Process process = Runtime.getRuntime().exec("logcat -d -s LocalDNS:V");
            BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()));
            StringBuilder logs = new StringBuilder();
            String line;
            List<String> lines = new ArrayList<>();
            while ((line = reader.readLine()) != null) {
                lines.add(line);
            }
            // Show last 50 lines
            int start = Math.max(0, lines.size() - 50);
            for (int i = start; i < lines.size(); i++) {
                logs.append(lines.get(i)).append("\n");
            }
            logsText.setText(logs.toString());
        } catch (Exception e) {
            logsText.setText("Erro ao ler logs: " + e.getMessage());
        }
    }
}
