package com.localdns.ui;
import android.content.Intent;
import android.net.VpnService;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.material.tabs.TabLayout;
import com.google.android.material.tabs.TabLayoutMediator;
import com.localdns.R;
import com.localdns.util.Constants;
import com.localdns.util.Logger;
import com.localdns.util.PermissionHelper;
import com.localdns.vpn.VpnManager;

public class MainActivity extends AppCompatActivity {
    private VpnManager vpnManager;
    private Handler uiHandler;
    private static final int VPN_REQUEST_CODE = 1000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        vpnManager = new VpnManager(this);
        uiHandler = new Handler(Looper.getMainLooper());

        setupViewPager();

        if (!PermissionHelper.hasNotifPerm(this)) {
            PermissionHelper.requestNotifPerm(this);
        }
    }

    private void setupViewPager() {
        ViewPager2 viewPager = findViewById(R.id.viewPager);
        TabLayout tabLayout = findViewById(R.id.tabLayout);

        viewPager.setAdapter(new FragmentStateAdapter(this) {
            @Override
            public int getItemCount() { return 3; }

            @Override
            public Fragment createFragment(int position) {
                switch (position) {
                    case 0: return new StatusFragment();
                    case 1: return new SettingsFragment();
                    case 2: return new LogsFragment();
                    default: return new StatusFragment();
                }
            }
        });

        new TabLayoutMediator(tabLayout, viewPager, (tab, pos) -> {
            switch (pos) {
                case 0: tab.setText("Status"); tab.setIcon(R.drawable.ic_vpn); break;
                case 1: tab.setText("Config"); tab.setIcon(R.drawable.ic_settings); break;
                case 2: tab.setText("Logs"); tab.setIcon(R.drawable.ic_stats); break;
            }
        }).attach();
    }

    public void requestVpnPermission() {
        Intent intent = VpnService.prepare(this);
        if (intent != null) {
            startActivityForResult(intent, VPN_REQUEST_CODE);
        } else {
            onVpnPermissionGranted();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == VPN_REQUEST_CODE) {
            if (resultCode == RESULT_OK) {
                onVpnPermissionGranted();
            } else {
                Toast.makeText(this, "Permissão VPN negada", Toast.LENGTH_LONG).show();
            }
        }
    }

    private void onVpnPermissionGranted() {
        vpnManager.startVpn();
        Toast.makeText(this, "VPN iniciada", Toast.LENGTH_SHORT).show();
    }

    public VpnManager getVpnManager() {
        return vpnManager;
    }

    public Handler getUiHandler() {
        return uiHandler;
    }
}
