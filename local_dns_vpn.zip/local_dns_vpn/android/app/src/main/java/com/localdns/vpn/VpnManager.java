package com.localdns.vpn;
import android.content.Context;
import android.content.Intent;
import android.net.VpnService;
import com.localdns.util.Constants;
import com.localdns.util.Logger;

public class VpnManager {
    private final Context context;
    private boolean isActive = false;

    public VpnManager(Context ctx) {
        this.context = ctx.getApplicationContext();
    }

    public boolean prepareVpn() {
        Intent intent = VpnService.prepare(context);
        if (intent != null) {
            // VPN permission dialog needed
            return false;
        }
        return true;
    }

    public void startVpn() {
        Intent intent = new Intent(context, LocalDnsVpnService.class);
        intent.setAction(Constants.ACTION_VPN_START);
        context.startService(intent);
        isActive = true;
        Logger.i("VPN start requested");
    }

    public void stopVpn() {
        Intent intent = new Intent(context, LocalDnsVpnService.class);
        intent.setAction(Constants.ACTION_VPN_STOP);
        context.startService(intent);
        isActive = false;
        Logger.i("VPN stop requested");
    }

    public boolean isActive() {
        return isActive;
    }

    public void setActive(boolean active) {
        this.isActive = active;
    }
}
