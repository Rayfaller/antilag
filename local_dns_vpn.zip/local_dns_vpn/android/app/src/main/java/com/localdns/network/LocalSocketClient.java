package com.localdns.network;
import com.localdns.util.Constants;
import com.localdns.util.Logger;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

public class LocalSocketClient {
    private DatagramSocket socket;

    public LocalSocketClient() {
        try {
            socket = new DatagramSocket();
            socket.setSoTimeout(Constants.DNS_TIMEOUT);
        } catch (Exception e) {
            Logger.e("Socket creation failed", e);
        }
    }

    public byte[] send(byte[] data) {
        if (socket == null) return null;
        try {
            InetAddress addr = InetAddress.getByName(Constants.TERMUX_RESOLVER_HOST);
            DatagramPacket req = new DatagramPacket(data, data.length, addr, Constants.TERMUX_PORT);
            socket.send(req);

            byte[] buf = new byte[Constants.DNS_MAX_SIZE];
            DatagramPacket resp = new DatagramPacket(buf, buf.length);
            socket.receive(resp);

            byte[] result = new byte[resp.getLength()];
            System.arraycopy(buf, 0, result, 0, resp.getLength());
            return result;
        } catch (Exception e) {
            Logger.e("Local socket send error", e);
            return null;
        }
    }

    public void close() {
        if (socket != null && !socket.isClosed()) {
            socket.close();
        }
    }
}
