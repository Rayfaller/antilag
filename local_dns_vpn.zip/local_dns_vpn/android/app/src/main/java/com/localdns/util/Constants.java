package com.localdns.util;

public class Constants {
    public static final String VPN_INTERFACE = "10.0.0.1";
    public static final int VPN_PREFIX = 24;
    public static final String VPN_DNS = "10.0.0.2";
    public static final int VPN_MTU = 1500;
    public static final String TERMUX_PKG = "com.termux";
    public static final String TERMUX_SOCK = "/data/data/com.termux/files/usr/tmp/local_dns.sock";
    public static final int TERMUX_PORT = 5353;
    public static final int DNS_MAX_SIZE = 4096;
    public static final int DNS_TIMEOUT = 5000;
    public static final String NOTIF_CHANNEL = "local_dns_vpn";
    public static final int NOTIF_ID = 1001;
    public static final String PREF_NAME = "LocalDnsPrefs";
    public static final String PREF_ACTIVE = "vpn_active";
    public static final String PREF_MODE = "mode";
}
