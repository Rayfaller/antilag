package com.localdns.model;
public class DnsQuery {
    public final byte[] rawData;
    public final String domain;
    public final int queryType;
    public final int transactionId;

    public DnsQuery(byte[] data) {
        this.rawData = data;
        this.transactionId = ((data[0] & 0xFF) << 8) | (data[1] & 0xFF);
        this.domain = extractDomain(data);
        this.queryType = extractType(data);
    }

    private static String extractDomain(byte[] d) {
        StringBuilder sb = new StringBuilder();
        int off = 12;
        while (off < d.length) {
            int len = d[off] & 0xFF;
            if (len == 0) break;
            if ((len & 0xC0) == 0xC0) break;
            if (sb.length() > 0) sb.append('.');
            off++;
            for (int i = 0; i < len && off < d.length; i++) sb.append((char)(d[off++] & 0xFF));
        }
        return sb.toString();
    }

    private static int extractType(byte[] d) {
        int off = 12;
        while (off < d.length) {
            int len = d[off++] & 0xFF;
            if (len == 0) { off += 2; break; }
            if ((len & 0xC0) == 0xC0) { off++; break; }
            off += len;
        }
        return (off + 2 <= d.length) ? ((d[off] & 0xFF) << 8) | (d[off + 1] & 0xFF) : 1;
    }

    public String getTypeName() {
        switch (queryType) {
            case 1: return "A"; case 2: return "NS"; case 5: return "CNAME";
            case 6: return "SOA"; case 12: return "PTR"; case 15: return "MX";
            case 16: return "TXT"; case 28: return "AAAA"; case 33: return "SRV";
            case 255: return "ANY"; default: return "TYPE_" + queryType;
        }
    }
}
