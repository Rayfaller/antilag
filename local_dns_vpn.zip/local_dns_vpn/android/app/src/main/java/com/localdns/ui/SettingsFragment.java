package com.localdns.ui;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Switch;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.localdns.R;
import com.localdns.util.Constants;

public class SettingsFragment extends Fragment {
    private Spinner modeSpinner;
    private Switch autoStartSwitch;
    private Button saveButton;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_settings, container, false);

        modeSpinner = view.findViewById(R.id.modeSpinner);
        autoStartSwitch = view.findViewById(R.id.autoStartSwitch);
        saveButton = view.findViewById(R.id.saveButton);

        String[] modes = {"FAST", "BALANCED", "STABLE"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(requireContext(), 
            android.R.layout.simple_spinner_item, modes);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        modeSpinner.setAdapter(adapter);

        loadSettings();

        saveButton.setOnClickListener(v -> saveSettings());

        return view;
    }

    private void loadSettings() {
        if (getActivity() == null) return;
        SharedPreferences prefs = getActivity().getSharedPreferences(Constants.PREF_NAME, 0);
        String mode = prefs.getString(Constants.PREF_MODE, "BALANCED");
        boolean autoStart = prefs.getBoolean(Constants.PREF_AUTO_START, false);

        int pos = 1; // Default BALANCED
        if (mode.equals("FAST")) pos = 0;
        else if (mode.equals("STABLE")) pos = 2;
        modeSpinner.setSelection(pos);
        autoStartSwitch.setChecked(autoStart);
    }

    private void saveSettings() {
        if (getActivity() == null) return;
        SharedPreferences prefs = getActivity().getSharedPreferences(Constants.PREF_NAME, 0);
        SharedPreferences.Editor editor = prefs.edit();

        String mode = (String) modeSpinner.getSelectedItem();
        editor.putString(Constants.PREF_MODE, mode);
        editor.putBoolean(Constants.PREF_AUTO_START, autoStartSwitch.isChecked());
        editor.apply();

        Toast.makeText(getContext(), "Configurações salvas", Toast.LENGTH_SHORT).show();
    }
}
