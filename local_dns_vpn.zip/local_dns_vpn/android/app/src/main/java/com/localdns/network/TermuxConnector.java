package com.localdns.network;
import com.localdns.util.Constants;
import com.localdns.util.Logger;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.Socket;
import java.nio.ByteBuffer;

public class TermuxConnector {
    private Socket socket;
    private InputStream input;
    private OutputStream output;
    private boolean connected = false;

    public TermuxConnector() {
        connect();
    }

    private void connect() {
        try {
            // Try Unix socket first
            java.io.File socketFile = new java.io.File(Constants.TERMUX_SOCK);
            if (socketFile.exists()) {
                socket = new Socket();
                socket.connect(new java.net.InetSocketAddress("localhost", 0));
                // Note: True Unix domain sockets require API 33+ (Android 13+)
                // For older Android, we use localhost TCP fallback
                input = socket.getInputStream();
                output = socket.getOutputStream();
                connected = true;
                Logger.i("Connected to Termux via TCP fallback");
            }
        } catch (Exception e) {
            Logger.d("Unix socket connection failed: " + e.getMessage());
            connected = false;
        }
    }

    public byte[] sendQuery(byte[] dnsData) {
        if (!connected) {
            connect();
            if (!connected) return null;
        }

        try {
            // Protocol: [1 byte type=0x01][4 bytes length][dns data]
            ByteBuffer buffer = ByteBuffer.allocate(1 + 4 + dnsData.length);
            buffer.put((byte) 0x01); // DNS Query type
            buffer.putInt(dnsData.length);
            buffer.put(dnsData);

            output.write(buffer.array());
            output.flush();

            // Read response length
            byte[] lenBytes = new byte[4];
            int read = input.read(lenBytes);
            if (read < 4) return null;

            int respLen = ByteBuffer.wrap(lenBytes).getInt();
            if (respLen <= 0 || respLen > Constants.DNS_MAX_SIZE) return null;

            byte[] response = new byte[respLen];
            int totalRead = 0;
            while (totalRead < respLen) {
                int r = input.read(response, totalRead, respLen - totalRead);
                if (r < 0) break;
                totalRead += r;
            }

            if (totalRead == respLen) {
                return response;
            }
        } catch (Exception e) {
            Logger.e("Send query error", e);
            connected = false;
        }
        return null;
    }

    public String getStats() {
        if (!connected) return null;
        try {
            ByteBuffer buffer = ByteBuffer.allocate(5);
            buffer.put((byte) 0x02); // Stats request
            buffer.putInt(0);
            output.write(buffer.array());
            output.flush();

            byte[] lenBytes = new byte[4];
            if (input.read(lenBytes) < 4) return null;
            int len = ByteBuffer.wrap(lenBytes).getInt();
            if (len <= 0 || len > 65535) return null;

            byte[] data = new byte[len];
            int total = 0;
            while (total < len) {
                int r = input.read(data, total, len - total);
                if (r < 0) break;
                total += r;
            }
            return new String(data, 0, total, "UTF-8");
        } catch (Exception e) {
            Logger.e("Get stats error", e);
            connected = false;
        }
        return null;
    }

    public void close() {
        try {
            if (socket != null && !socket.isClosed()) {
                socket.close();
            }
        } catch (Exception e) {
            Logger.e("Close error", e);
        }
        connected = false;
    }
}
