package com.localdns.model;
public class ServerStats {
    public String upstream = "Unknown";
    public long latencyMs = 0;
    public double cacheHitRate = 0.0;
    public long totalQueries = 0;
    public long totalFailures = 0;
    public long fallbackCount = 0;
    public String uptime = "00:00:00";
    public boolean isRunning = false;
    public String mode = "balanced";
}
