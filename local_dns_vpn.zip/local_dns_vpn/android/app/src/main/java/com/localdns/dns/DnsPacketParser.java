package com.localdns.dns;
import com.localdns.model.DnsQuery;
import com.localdns.model.DnsResponse;
import com.localdns.util.Logger;
public class DnsPacketParser {
    public static DnsQuery parseQuery(byte[] data) {
        if (data == null || data.length < 12) return null;
        try {
            return new DnsQuery(data);
        } catch (Exception e) {
            Logger.e("Parse query error", e);
            return null;
        }
    }

    public static boolean isValidDnsPacket(byte[] data) {
        if (data == null || data.length < 12) return false;
        int flags = ((data[2] & 0xFF) << 8) | (data[3] & 0xFF);
        boolean isResponse = (flags & 0x8000) != 0;
        return !isResponse; // Must be a query
    }

    public static byte[] buildErrorResponse(byte[] query, int rcode) {
        if (query == null || query.length < 12) return new byte[0];
        byte[] resp = new byte[12];
        System.arraycopy(query, 0, resp, 0, 2); // Copy transaction ID
        int flags = 0x8000 | (rcode & 0x000F); // Response + RCODE
        resp[2] = (byte) ((flags >> 8) & 0xFF);
        resp[3] = (byte) (flags & 0xFF);
        resp[4] = query[4]; resp[5] = query[5]; // QDCOUNT
        resp[6] = 0; resp[7] = 0; // ANCOUNT
        resp[8] = 0; resp[9] = 0; // NSCOUNT
        resp[10] = 0; resp[11] = 0; // ARCOUNT
        return resp;
    }
}
