package com.localdns.dns;
import android.net.VpnService;
import com.localdns.util.Constants;
import com.localdns.util.Logger;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.net.InetSocketAddress;
import java.nio.ByteBuffer;
import java.nio.channels.DatagramChannel;

public class DnsInterceptor {
    private final VpnService vpnService;
    private Thread interceptorThread;
    private boolean running = false;
    private FileInputStream vpnIn;
    private FileOutputStream vpnOut;
    private DnsForwarder forwarder;

    public DnsInterceptor(VpnService service, FileInputStream in, FileOutputStream out) {
        this.vpnService = service;
        this.vpnIn = in;
        this.vpnOut = out;
        this.forwarder = new DnsForwarder();
    }

    public void start() {
        if (running) return;
        running = true;
        interceptorThread = new Thread(this::interceptLoop, "DNS-Interceptor");
        interceptorThread.start();
        Logger.i("DNS Interceptor started");
    }

    public void stop() {
        running = false;
        if (interceptorThread != null) {
            interceptorThread.interrupt();
        }
        Logger.i("DNS Interceptor stopped");
    }

    private void interceptLoop() {
        byte[] buffer = new byte[Constants.DNS_MAX_SIZE];
        while (running && !Thread.interrupted()) {
            try {
                int length = vpnIn.read(buffer);
                if (length <= 0) continue;

                // Check if it's a DNS packet (UDP to port 53)
                if (isDnsPacket(buffer, length)) {
                    byte[] dnsData = extractDnsPayload(buffer, length);
                    if (dnsData != null) {
                        byte[] response = forwarder.forward(dnsData);
                        if (response != null) {
                            byte[] packet = buildResponsePacket(buffer, length, response);
                            vpnOut.write(packet);
                        }
                    }
                }
                // Non-DNS packets are dropped (we only intercept DNS)
            } catch (Exception e) {
                if (running) Logger.e("Interceptor error", e);
            }
        }
    }

    private boolean isDnsPacket(byte[] packet, int len) {
        if (len < 28) return false; // IP header (20) + UDP header (8) minimum
        // Check UDP destination port 53
        int destPort = ((packet[22] & 0xFF) << 8) | (packet[23] & 0xFF);
        return destPort == 53;
    }

    private byte[] extractDnsPayload(byte[] packet, int len) {
        // IP header length (IHL * 4)
        int ipHeaderLen = (packet[0] & 0x0F) * 4;
        // UDP header is 8 bytes
        int dnsOffset = ipHeaderLen + 8;
        if (dnsOffset >= len) return null;
        byte[] dns = new byte[len - dnsOffset];
        System.arraycopy(packet, dnsOffset, dns, 0, dns.length);
        return dns;
    }

    private byte[] buildResponsePacket(byte[] original, int origLen, byte[] dnsResponse) {
        // Swap source/dest IP and ports, update lengths
        int ipHeaderLen = (original[0] & 0x0F) * 4;
        byte[] packet = new byte[ipHeaderLen + 8 + dnsResponse.length];

        // Copy IP header
        System.arraycopy(original, 0, packet, 0, ipHeaderLen);

        // Swap source and destination IP
        for (int i = 0; i < 4; i++) {
            byte tmp = packet[12 + i];
            packet[12 + i] = packet[16 + i];
            packet[16 + i] = tmp;
        }

        // Copy UDP header and swap ports
        System.arraycopy(original, ipHeaderLen, packet, ipHeaderLen, 8);
        byte tmpPort = packet[ipHeaderLen];
        packet[ipHeaderLen] = packet[ipHeaderLen + 2];
        packet[ipHeaderLen + 2] = tmpPort;
        tmpPort = packet[ipHeaderLen + 1];
        packet[ipHeaderLen + 1] = packet[ipHeaderLen + 3];
        packet[ipHeaderLen + 3] = tmpPort;

        // Copy DNS response
        System.arraycopy(dnsResponse, 0, packet, ipHeaderLen + 8, dnsResponse.length);

        // Update IP total length
        int totalLen = packet.length;
        packet[2] = (byte) ((totalLen >> 8) & 0xFF);
        packet[3] = (byte) (totalLen & 0xFF);

        // Update UDP length
        int udpLen = 8 + dnsResponse.length;
        packet[ipHeaderLen + 4] = (byte) ((udpLen >> 8) & 0xFF);
        packet[ipHeaderLen + 5] = (byte) (udpLen & 0xFF);

        return packet;
    }
}
