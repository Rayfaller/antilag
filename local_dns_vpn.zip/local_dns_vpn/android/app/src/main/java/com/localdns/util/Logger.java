package com.localdns.util;
import android.util.Log;
public class Logger {
    private static final String TAG = "LocalDNS";
    public static void d(String m) { Log.d(TAG, m); }
    public static void i(String m) { Log.i(TAG, m); }
    public static void w(String m) { Log.w(TAG, m); }
    public static void e(String m) { Log.e(TAG, m); }
    public static void e(String m, Throwable t) { Log.e(TAG, m, t); }
}
