package com.localdns.vpn;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.SharedPreferences;
import android.net.VpnService;
import android.os.Build;
import android.os.ParcelFileDescriptor;
import android.os.Handler;
import android.os.Looper;

import androidx.core.app.NotificationCompat;

import com.localdns.dns.DnsInterceptor;
import com.localdns.ui.MainActivity;
import com.localdns.util.Constants;
import com.localdns.util.Logger;

import java.io.FileInputStream;
import java.io.FileOutputStream;

public class LocalDnsVpnService extends VpnService {
    private ParcelFileDescriptor vpnInterface;
    private DnsInterceptor dnsInterceptor;
    private Thread vpnThread;
    private boolean running = false;
    private Handler mainHandler;

    @Override
    public void onCreate() {
        super.onCreate();
        mainHandler = new Handler(Looper.getMainLooper());
        createNotificationChannel();
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent == null) return START_NOT_STICKY;

        String action = intent.getAction();
        if (Constants.ACTION_VPN_START.equals(action)) {
            startVpn();
        } else if (Constants.ACTION_VPN_STOP.equals(action)) {
            stopVpn();
        }
        return START_NOT_STICKY;
    }

    private void startVpn() {
        if (running) return;

        try {
            // Build VPN interface
            Builder builder = new Builder()
                .addAddress(Constants.VPN_INTERFACE, Constants.VPN_PREFIX)
                .addDnsServer(Constants.VPN_DNS)
                .addRoute(Constants.VPN_ROUTE, Constants.VPN_ROUTE_PREFIX)
                .setMtu(Constants.VPN_MTU)
                .setBlocking(true)
                .setSession("LocalDNS");

            // CRITICAL: Exclude Termux to prevent loop
            // VPN -> DNS -> VPN -> DNS (infinite loop)
            builder.addDisallowedApplication(Constants.TERMUX_PKG);

            // Also exclude self to be safe
            builder.addDisallowedApplication(getPackageName());

            vpnInterface = builder.establish();
            if (vpnInterface == null) {
                Logger.e("Failed to establish VPN interface");
                return;
            }

            FileInputStream in = new FileInputStream(vpnInterface.getFileDescriptor());
            FileOutputStream out = new FileOutputStream(vpnInterface.getFileDescriptor());

            dnsInterceptor = new DnsInterceptor(this, in, out);
            dnsInterceptor.start();

            running = true;
            updatePrefs(true);
            startForeground(Constants.NOTIF_ID, buildNotification());
            Logger.i("VPN started successfully");

        } catch (Exception e) {
            Logger.e("VPN start failed", e);
            stopSelf();
        }
    }

    private void stopVpn() {
        running = false;
        if (dnsInterceptor != null) {
            dnsInterceptor.stop();
        }
        if (vpnInterface != null) {
            try {
                vpnInterface.close();
            } catch (Exception e) {
                Logger.e("Error closing VPN interface", e);
            }
            vpnInterface = null;
        }
        updatePrefs(false);
        stopForeground(true);
        stopSelf();
        Logger.i("VPN stopped");
    }

    @Override
    public void onDestroy() {
        stopVpn();
        super.onDestroy();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationChannel channel = new NotificationChannel(
                Constants.NOTIF_CHANNEL,
                "Local DNS VPN",
                NotificationManager.IMPORTANCE_LOW
            );
            channel.setDescription("Local DNS resolver active");
            NotificationManager manager = getSystemService(NotificationManager.class);
            if (manager != null) {
                manager.createNotificationChannel(channel);
            }
        }
    }

    private Notification buildNotification() {
        Intent intent = new Intent(this, MainActivity.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(
            this, 0, intent, PendingIntent.FLAG_IMMUTABLE
        );

        return new NotificationCompat.Builder(this, Constants.NOTIF_CHANNEL)
            .setContentTitle("Local DNS VPN")
            .setContentText("DNS resolver active - queries being intercepted")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentIntent(pendingIntent)
            .setOngoing(true)
            .build();
    }

    private void updatePrefs(boolean active) {
        SharedPreferences prefs = getSharedPreferences(Constants.PREF_NAME, MODE_PRIVATE);
        prefs.edit().putBoolean(Constants.PREF_ACTIVE, active).apply();
    }

    public boolean isRunning() {
        return running;
    }
}
