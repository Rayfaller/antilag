package com.localdns.ui;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.localdns.R;
import com.localdns.network.TermuxConnector;
import com.localdns.util.Constants;
import com.localdns.util.Logger;

import org.json.JSONObject;

public class StatusFragment extends Fragment {
    private Button toggleButton;
    private TextView statusText;
    private TextView dnsText;
    private TextView latencyText;
    private TextView cacheText;
    private TextView queriesText;
    private TextView upstreamText;
    private TextView uptimeText;
    private Handler updateHandler;
    private Runnable updateRunnable;
    private boolean isVpnActive = false;
    private TermuxConnector connector;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_status, container, false);

        toggleButton = view.findViewById(R.id.toggleButton);
        statusText = view.findViewById(R.id.statusText);
        dnsText = view.findViewById(R.id.dnsText);
        latencyText = view.findViewById(R.id.latencyText);
        cacheText = view.findViewById(R.id.cacheText);
        queriesText = view.findViewById(R.id.queriesText);
        upstreamText = view.findViewById(R.id.upstreamText);
        uptimeText = view.findViewById(R.id.uptimeText);

        connector = new TermuxConnector();
        updateHandler = new Handler(Looper.getMainLooper());

        toggleButton.setOnClickListener(v -> toggleVpn());

        updateRunnable = new Runnable() {
            @Override
            public void run() {
                updateStatus();
                updateHandler.postDelayed(this, 2000);
            }
        };

        return view;
    }

    @Override
    public void onResume() {
        super.onResume();
        loadSavedState();
        updateHandler.post(updateRunnable);
    }

    @Override
    public void onPause() {
        super.onPause();
        updateHandler.removeCallbacks(updateRunnable);
    }

    private void loadSavedState() {
        if (getActivity() == null) return;
        SharedPreferences prefs = getActivity().getSharedPreferences(Constants.PREF_NAME, 0);
        isVpnActive = prefs.getBoolean(Constants.PREF_ACTIVE, false);
        updateUI();
    }

    private void toggleVpn() {
        MainActivity activity = (MainActivity) getActivity();
        if (activity == null) return;

        if (isVpnActive) {
            activity.getVpnManager().stopVpn();
            isVpnActive = false;
        } else {
            activity.requestVpnPermission();
            isVpnActive = true;
        }
        updateUI();
    }

    private void updateUI() {
        if (isVpnActive) {
            toggleButton.setText("DESATIVAR VPN");
            toggleButton.setBackgroundColor(0xFFE53935); // Red
            statusText.setText("🟢 ATIVO");
            statusText.setTextColor(0xFF4CAF50);
            dnsText.setText("DNS: " + Constants.VPN_DNS);
        } else {
            toggleButton.setText("ATIVAR VPN");
            toggleButton.setBackgroundColor(0xFF43A047); // Green
            statusText.setText("🔴 INATIVO");
            statusText.setTextColor(0xFFE53935);
            dnsText.setText("DNS: Padrão do sistema");
            latencyText.setText("Latência: --");
            cacheText.setText("Cache HIT: --");
            queriesText.setText("Consultas: --");
            upstreamText.setText("Upstream: --");
            uptimeText.setText("Uptime: --");
        }
    }

    private void updateStatus() {
        if (!isVpnActive || getActivity() == null) return;

        try {
            String statsJson = connector.getStats();
            if (statsJson != null) {
                JSONObject stats = new JSONObject(statsJson);

                String upstream = stats.optString("upstream", "Unknown");
                upstreamText.setText("Upstream: " + upstream);

                long latency = stats.optLong("avg_latency_ms", 0);
                latencyText.setText("Latência: " + latency + " ms");

                JSONObject cache = stats.optJSONObject("cache");
                if (cache != null) {
                    double hitRate = cache.optDouble("hit_rate", 0);
                    cacheText.setText("Cache HIT: " + hitRate + "%");
                }

                long queries = stats.optLong("total_queries", 0);
                queriesText.setText("Consultas: " + queries);

                String uptime = stats.optString("uptime_formatted", "00:00:00");
                uptimeText.setText("Uptime: " + uptime);
            }
        } catch (Exception e) {
            Logger.d("Update status error: " + e.getMessage());
        }
    }
}
