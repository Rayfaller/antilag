package com.localdns.model;
public class DnsResponse {
    public final byte[] rawData;
    public final int transactionId;
    public final int responseCode;
    public final int answerCount;

    public DnsResponse(byte[] data) {
        this.rawData = data;
        if (data.length >= 12) {
            this.transactionId = ((data[0] & 0xFF) << 8) | (data[1] & 0xFF);
            int flags = ((data[2] & 0xFF) << 8) | (data[3] & 0xFF);
            this.responseCode = flags & 0x000F;
            this.answerCount = ((data[6] & 0xFF) << 8) | (data[7] & 0xFF);
        } else {
            this.transactionId = 0; this.responseCode = 2; this.answerCount = 0;
        }
    }
    public boolean isSuccess() { return responseCode == 0; }
    public boolean isNxDomain() { return responseCode == 3; }
}
