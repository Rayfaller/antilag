#!/usr/bin/env python3
"""
Local DNS VPN - Build Script
Builds and packages the complete project.
"""

import os
import shutil
import subprocess
import sys

def build_termux():
    print("Building Termux components...")
    # Python is already source, just verify
    result = subprocess.run([sys.executable, "-m", "py_compile", 
                            "termux/resolver/engine.py"],
                           capture_output=True)
    if result.returncode != 0:
        print("ERROR: Python syntax check failed")
        return False
    print("✓ Termux components OK")
    return True

def build_android():
    print("Building Android app...")
    android_dir = os.path.join(os.path.dirname(__file__), "android")
    if not os.path.exists(android_dir):
        print("ERROR: android/ directory not found")
        return False

    gradlew = os.path.join(android_dir, "gradlew" if os.name != 'nt' else "gradlew.bat")
    if os.path.exists(gradlew):
        result = subprocess.run([gradlew, "assembleDebug"],
                               cwd=android_dir,
                               capture_output=True,
                               text=True)
        if result.returncode == 0:
            print("✓ Android APK built")
            apk_path = os.path.join(android_dir, "app/build/outputs/apk/debug/app-debug.apk")
            if os.path.exists(apk_path):
                print(f"  APK: {apk_path}")
            return True
        else:
            print(f"ERROR: {result.stderr}")
            return False
    else:
        print("WARNING: gradlew not found, skipping Android build")
        return True

def package():
    print("Packaging...")
    dist_dir = "dist"
    os.makedirs(dist_dir, exist_ok=True)

    # Copy Termux components
    termux_dist = os.path.join(dist_dir, "termux")
    if os.path.exists(termux_dist):
        shutil.rmtree(termux_dist)
    shutil.copytree("termux", termux_dist)
    shutil.copytree("config", os.path.join(dist_dir, "config"))
    shutil.copy("requirements.txt", dist_dir)

    # Copy Android APK if built
    apk = "android/app/build/outputs/apk/debug/app-debug.apk"
    if os.path.exists(apk):
        shutil.copy(apk, os.path.join(dist_dir, "local-dns-vpn.apk"))

    # Copy docs
    shutil.copytree("docs", os.path.join(dist_dir, "docs"))

    print(f"✓ Packaged in {dist_dir}/")
    return True

def main():
    print("=" * 50)
    print("Local DNS VPN - Build")
    print("=" * 50)

    success = True
    success = build_termux() and success
    success = build_android() and success

    if success:
        package()
        print("\nBuild completed successfully!")
    else:
        print("\nBuild failed!")
        sys.exit(1)

if __name__ == "__main__":
    main()
